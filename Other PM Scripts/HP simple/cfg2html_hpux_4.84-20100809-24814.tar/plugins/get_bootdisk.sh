#!/sbin/sh
# @(#) $Id: get_bootdisk.sh,v 4.11 2008-11-13 19:53:43 ralproth Exp $
# by Thomas Brix - works only with HPUX 11i v2 and above!!!
# not used in cfg2html yet!

lssf $(ls -l /dev/d*sk/* | grep $(echo "bootdev/x" | \
adb /stand/vmunix /dev/kmem | grep 0x | \
sed 's/0x..//') | head -1 | awk '{print $NF}') | \
awk '{print "This system last booted from " $NF " " $(NF-1)}'
