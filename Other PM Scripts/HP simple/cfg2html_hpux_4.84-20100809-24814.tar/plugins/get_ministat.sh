# Mini Status Collector
############################################################
# @(#) $Id: get_ministat.sh,v 4.11 2008-11-13 19:53:44 ralproth Exp $
# $Log: get_ministat.sh,v $
# Revision 4.11  2008-11-13 19:53:44  ralproth
# cfg4.13: cleanup of cvs keywords (2nd round)
#
# Revision 4.10.1.1  2008/02/28 02:55:04  ralproth
# Initial cfg2html_hpux 4.xx stream import
#
# Revision 3.17  2008/02/28 02:55:03  ralproth
# cfg3.61: netstat, misc. stuff
#
# Revision 3.16  2008/02/26 20:30:12  ralproth
# Revision 3.11  2007/03/20 01:01:00  ralproth
# Revision 3.10.1.1  2004/09/09 18:53:48  ralproth
# Revision 2.1  2003/05/20 13:39:40  ralproth
############################################################

# Meulen, H.R. van der (Hans) - 14.03.2007 13:40 Today I took a look at the
# plugin get_ministat.sh and found that the number of cpu�s in a vpar was not
# calculated correct. The number of cpu was added to the number of io devices. I
# think that it does not matter if your on a n-par or v-par or physical machine
# the initial cpu�s is calculated correct.
# Ioscan �k | grep processor | wc -l works fine for the three of them

# echo "\nsel d 1\ninfo\nwait\nil\n\nexit\n\n" | cstm | grep "System Serial"
# Get CPUs ## #  09.09.2004, 11:30 modified by Ralph.Roth at hp.com  (HPS-TSG-MCPS)
# Mueller Ltd. & Co. KG >> 09. September 2004 << Gernot Wolf

CPU=$(ioscan -k|grep processor|wc -l)
if [ -r /stand/vpmon ]
then
	HOSTNAME=`vparstatus -w | awk '{ print $6 }'`

	CPUS=`vparstatus | grep $HOSTNAME | awk '!/Up/ { print $4, $5 }'`
	CPU1=`echo $CPUS | awk '{ print $1 }'`
	CPU2=`echo $CPUS | awk '{ print $2 }'`

	(( CPU = CPU1 + CPU2 ))
fi

echo "Hostname          " $(hostname)
echo "Model             " $(getconf MACHINE_MODEL)
echo "uname -a          " $(uname -a)
echo "Software ID       " $(getconf MACHINE_SERIAL) " (not available on every machine)"
echo "# CPUs            " $CPU" (may include iCOD CPUs)"
echo "# disks           " $(ioscan -k|grep disk|grep -v 'D-ROM'|wc -l)
MEM=$(head -l -n 2200 /var/adm/syslog/syslog.log|grep Physical|grep avail|cut -c 34-|dos2ux)
[ -z "$MEM" ] && MEM=$(dmesg|grep Physical|grep avail|cut -c 4-|dos2ux)
## fix for hpux 11i v3, thx: Steve Yakes
[ -z "$MEM" ] && MEM=$(grep System /var/adm/syslog/syslog.log|grep vmunix: | awk -F"System" '{print $1;}')
echo "Memory            " $MEM

# Note: on 11i Version 1 the command "getconf MACHINE_SERIAL" would not return
# the serial number of the system (it only gives the software id not the serial
# number, if it gives anything at all). From 11i Version 1.5 this command works
# correctly on IA and PA systems and should be used in preference to getsn (note
# that getsn will never be ported to Itanium systems).

swapinfo -tam | awk '

/dev/	{ dev += $2; lvol++ };
/memory/   { mem += $2; };

{}

END {
	printf ("Deviceswap         %ld MB\n", dev);
	#printf ("# of devices = %ld\n", lvol);
	printf ("Memory swapable    %ld MB\n", mem);

	#printf  ("'$(hostname)';%ld;%ld;%ld;\n", lvol, dev, mem);
}
'



