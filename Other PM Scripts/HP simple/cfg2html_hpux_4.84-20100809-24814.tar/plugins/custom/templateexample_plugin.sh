#!/bin/sh
# ---------------------------------------------------------------------------
# custom example plugin, provided by Andre Naumann, 25. August 2009
# @(#) $Id: templateexample_plugin.sh,v 1.1 2009-08-25 06:47:00 ralproth Exp $
# ---------------------------------------------------------------------------

CFG2HTML_PLUGINTITLE="Example Plugin: This will go into the section title for each plugin"

function cfg2html_plugin {
        echo "Here you can add a shell script, all output to stdout will be added to the"
        echo "cfg2html output file."

        echo "The PID of this plugin run was " $$
}

