###################################################################
# lpstat replacement plug in, (c) 20-july-2001 by ralph roth
# @(#) $Id: getlp.sh,v 4.11 2008-11-13 19:53:44 ralproth Exp $
###################################################################
# $Log: getlp.sh,v $
# Revision 4.11  2008-11-13 19:53:44  ralproth
# cfg4.13: cleanup of cvs keywords (2nd round)
#
# Revision 4.10.1.1  2003/01/21 10:33:34  ralproth
# Initial cfg2html_hpux 4.xx stream import
#
# Revision 3.10.1.1  2003/01/21 10:33:33  ralproth
# Initial 3.x stream import
#
# Revision 2.1.1.1  2003/01/21 10:33:33  ralproth
# Import from HPUX to cygwin
#
# Revision 1.3  2002/11/20 11:51:36  ralproth
# Changes for proper WinCVS function
#
# Revision 1.2  2001/07/20 15:26:56  root
# cfg2html 1.52
#
# Revision 1.1  2001/07/20  15:29:31  15:29:31  root (Guru Ralph)
# Initial revision
# 
###################################################################
/usr/sam/lbin/lpmgr -l | awk -F":" '{
	if (NF > 3) {
	for (t = 1; t < 4; t++)
		{ printf("%-20s ", $t); };
	printf("%s\n", $5);
	}
}' 
