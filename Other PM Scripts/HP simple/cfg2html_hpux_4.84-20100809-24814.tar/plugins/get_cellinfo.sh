# @(#) $Id: get_cellinfo.sh,v 4.11 2008-11-13 19:53:43 ralproth Exp $
# $Log: get_cellinfo.sh,v $
# Revision 4.11  2008-11-13 19:53:43  ralproth
# cfg4.13: cleanup of cvs keywords (2nd round)
#
# Revision 4.10.1.1  2007/11/26 19:03:34  ralproth
# Initial cfg2html_hpux 4.xx stream import
#
# Revision 3.1  2007/11/26 19:03:34  ralproth
# Added Files:
# 	get_cellinfo.sh get_cputype.sh
#
#
######################################################################
# exec_command SuperDome "SuperDome Configuration"
######################################################################

SuperDomeInfo( )
{
	 PAR=`parstatus -M -P |wc -l`      # number of partitions
	 CELL=`parstatus -M -C |wc -l`     # number of cells
	 CELL=`expr $CELL - 1`             # justify # of lines
	 CAB=`parstatus -M -B |wc -l`      # number of cabinets
	 CAB=`expr $CAB - 1`               # justify # of lines

	 echo "general overview"
	 echo "----------------"
	 parstatus                         # display general data
	 echo ""
	 echo ""
	 echo ""

	 echo "detailed partition data"
	 echo "-----------------------"
	 i=0
	 while [ i -lt $PAR ]
	 do
	  parstatus -V -p $i               # display detailed partition data
	  i=`expr $i + 1`
	 done
	 echo ""
	 echo ""
	 echo ""

	 echo "detailed cell data"
	 echo "------------------"
	 i=0
	 while [ i -lt $CELL ]
	 do
	  parstatus -V -c $i               # display detailed cell data
	  i=`expr $i + 1`
	 done
	 echo ""
	 echo ""
	 echo ""

	 echo "detailed cabinet data"
	 echo "---------------------"
	 i=0
	 while [ i -lt $CAB ]
	 do
	  parstatus -V -b $i               # display detailed cabinet data
	  i=`expr $i + 1`
	 done
	 echo ""
}
#################################################################

if [ -z "$CFG2HTML" ]           # only execute if not called from
then                            # cfg2html directly!
        SuperDomeInfo
fi

