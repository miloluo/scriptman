CREATE GLOBAL TEMPORARY TABLE e$ksmsp ON COMMIT PRESERVE ROWS AS
SELECT      a.ksmchcom,
         SUM (a.CHUNK) CHUNK,
         SUM (a.recr) recr,
         SUM (a.freeabl) freeabl,
         SUM (a.SUM) SUM
    FROM (SELECT   ksmchcom, COUNT (ksmchcom) CHUNK,
                   DECODE (ksmchcls, 'recr', SUM (ksmchsiz), NULL) recr,
                   DECODE (ksmchcls, 'freeabl', SUM (ksmchsiz), NULL) freeabl,
                   SUM (ksmchsiz) SUM
              FROM x$ksmsp GROUP BY ksmchcom, ksmchcls) a
where 1 = 0
GROUP BY a.ksmchcom;
