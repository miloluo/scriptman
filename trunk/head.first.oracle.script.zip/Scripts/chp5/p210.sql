create or replace PROCEDURE pining
IS
BEGIN
        NULL;
END;
/


create or replace procedure calling
is
begin
        pining;
        dbms_lock.sleep(3000);
end;
/
