SELECT *
  FROM (SELECT   addr, ts#, file#, dbarfil, dbablk, tch
            FROM x$bh
        ORDER BY tch DESC)
 WHERE ROWNUM < 11;
