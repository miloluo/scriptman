SELECT *
  FROM (SELECT   addr, child#, gets, misses, sleeps, immediate_gets igets,
                 immediate_misses imiss, spin_gets sgets
            FROM v$latch_children
           WHERE NAME = 'cache buffers chains'
        ORDER BY sleeps DESC)
 WHERE ROWNUM < 11;
