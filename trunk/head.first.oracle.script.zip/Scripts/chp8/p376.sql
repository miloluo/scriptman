SELECT *
  FROM (SELECT   event, time_waited
            FROM v$system_event
        ORDER BY time_waited DESC)
 WHERE ROWNUM < 10;
