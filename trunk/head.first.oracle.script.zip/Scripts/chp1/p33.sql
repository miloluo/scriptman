SELECT recovery_estimated_ios reios, target_mttr tmttr, estimated_mttr emttr,
       writes_mttr wmttr, writes_other_settings woset,
       ckpt_block_writes ckptbw, writes_autotune wauto,
       writes_full_thread_ckpt wftckpt
  FROM v$instance_recovery;