SELECT NAME, VALUE,
         100
       * (  VALUE
          / DECODE ((SELECT SUM (VALUE) FROM v$sysstat
                    WHERE NAME LIKE 'workarea executions%'),
                    0, NULL,
                    (SELECT SUM (VALUE) FROM v$sysstat
                    WHERE NAME LIKE 'workarea executions%')
                   )
         ) pct
  FROM v$sysstat
 WHERE NAME LIKE 'workarea executions%'
/
