SELECT pga_target_factor factor, low_optimal_size / 1024 low,
       ROUND (high_optimal_size / 1024) high,
       estd_optimal_executions estd_opt, estd_onepass_executions estd_op,
       estd_multipasses_executions estd_mp, estd_total_executions estd_exec
  FROM v$pga_target_advice_histogram
 WHERE pga_target_factor = 0.25 AND estd_total_executions > 0
/
