CREATE OR REPLACE VIEW redo_size
AS
   SELECT VALUE
     FROM v$mystat, v$statname
    WHERE v$mystat.statistic# = v$statname.statistic#
      AND v$statname.NAME = 'redo size'
/