SELECT NAME, completion_time, blocks * block_size / 1024 / 1024 mb
  FROM v$archived_log
 WHERE ROWNUM < 11
   AND completion_time BETWEEN TRUNC (SYSDATE) - 2 AND TRUNC (SYSDATE) - 1
/

SELECT   TRUNC (completion_time), SUM (mb) / 1024 day_gb
    FROM (SELECT NAME, completion_time, blocks * block_size / 1024 / 1024 mb
            FROM v$archived_log
           WHERE completion_time BETWEEN TRUNC (SYSDATE) - 2 AND   TRUNC
                                                                      (SYSDATE)
                                                                 - 1)
GROUP BY TRUNC (completion_time)
/

SELECT   TRUNC (completion_time), SUM (mb) / 1024 day_gb
      FROM (SELECT NAME, completion_time, blocks * block_size / 1024 / 1024 mb
              FROM v$archived_log)
GROUP BY TRUNC (completion_time)
/


