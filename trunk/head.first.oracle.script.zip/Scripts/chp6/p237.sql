alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss';
 
select startup_time from v$instance;
 
select (select value/1024/1024/1024 from v$sysstat where name='redo size')/
(select round(sysdate - ( select startup_time from v$instance)) from dual) REDO_GB_PER_DAY
from dual;
