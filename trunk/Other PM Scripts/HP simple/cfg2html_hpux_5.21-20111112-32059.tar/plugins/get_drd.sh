#!/bin/sh
# ---------------------------------------------------------------------------
# @(#)  DRD plugin, provided by Thomas Brix, 02. Feb 2011
# ---------------------------------------------------------------------------

# @(#) $Id: get_drd.sh,v 5.10.1.1 2011-02-15 14:29:05 ralproth Exp $
# -----------------------------------------------------------------------------------------
# (c) 1997 - 2011 by Ralph Roth  -*- http://come.to/rose_swe -*-


CFG2HTML_PLUGINTITLE="Dynamic Root Disk (DRD) Plugin"
F=/opt/drd/bin/drd
L=/var/opt/drd/drd.log

#function cfg2html_plugin {
        [ -x $F ] && /usr/bin/what $F
        if [ -r $L ]
        then
                echo wc -l $L; wc -l $L
                echo \\ntail -100 $L; tail -100 $L
        else
		echo no $L found
        fi
        #echo "The PID of this plugin run was " $$
#}
