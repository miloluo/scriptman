# Initial version provided 25-Jul-2003 by Martin Kalmbach, ASO SW, HP
# ---------------------------------------------------------------------------
# Seems to have problems under HP-UX 11.31?
# @(#) $Id: check_space.sh,v 5.10.1.1 2011-02-15 14:29:05 ralproth Exp $
# $Log: check_space.sh,v $
# Revision 5.10.1.1  2011-02-15 14:29:05  ralproth
# Initial 5.xx import
#
# Revision 4.13  2010-02-02 15:25:54  ralproth
# cfg4.63-23633: new version provided by Michael Meyer
#
# Revision 4.12  2008-11-13 20:22:56  ralproth
# cfg4.13: fixes for mywhat utility
#
# Revision 4.11  2008/11/13 19:46:25  ralproth
# cfg4.13: changed cvs keywords for new _what_ utility
#
# Revision 4.10.1.1  2008/10/24 11:48:18  ralproth
# Initial cfg2html_hpux 4.xx stream import
#
# Revision 3.11  2008/10/24 10:48:17  ralproth
# cfg3.72: Fixes for HP-UX 11.31
#
# Revision 3.10.1.1  2004/02/16 09:32:02  ralproth
# Initial 3.x stream import
#
# Revision 2.7  2004/02/16 09:32:02  ralproth
# Updated version provided by martin kalmbach
#
# Revision 2.4  2003/03/11 17:36:07  www
# Latest fixes by Martin Kalmbach
#
# Revision 2.2  2003/03/11 08:09:47  ralproth
# Fixes from Martin Kalmbach
#
# Revision 2.1  2003/03/11 07:59:46  ralproth
# Initial import from Martin's sources
#
FILTER="-v -E 'byte|^DevFS|Filesystem'"
export LANG=C 
PATH=/sbin:/usr/sbin:/usr/bin:$PATH
# set -vx

echo "================================================================"
for vg in `vgdisplay -v 2>/dev/null|awk -F'/' '/^VG Name/ {print $NF}'|sort -u`
do
    vgexport -p -s -m $vg.maps.temp $vg 1>/dev/null 2>&1
    VGID=`head -1 $vg.maps.temp`
    rm $vg.maps.temp
    PESIZE=`  vgdisplay $vg | awk '/PE Size/  {print $4}' `
    MAXPE=`   vgdisplay $vg | awk '/Max PE/   {print $5}' `
    MAXPV=`   vgdisplay $vg | awk '/Max PV/   {print $3}' `
    CURPV=`   vgdisplay $vg | awk '/Cur PV/   {print $3}' `
    ALLPE=`   vgdisplay $vg | awk '/Alloc PE/ {print $3}' `
    FREEPE=`  vgdisplay $vg | awk '/Free PE/  {print $3}' `
    TOTALPE=` vgdisplay $vg | awk '/Total PE/ {print $3}' `
    ((ALLOCMB=$PESIZE*$ALLPE))
    ((TOTALMB=$PESIZE*$TOTALPE))
    ((FREEMB=$PESIZE*$FREEPE))
    ((MAXDISKSIZE=$PESIZE*$MAXPE))
    echo "Volumegroup Informations for $vg ($VGID)"
    echo "PESize=$PESIZE MaxPE=$MAXPE MaxPV=$MAXPV CurPV=$CURPV MaxDiskSize=$MAXDISKSIZE MB"
    echo "----------------------------------------------------------------"
    
    echo "Total capacity in Volumegroup $vg               : $TOTALMB MB"
    echo "Allocated capacity in Volumegroup $vg           : $ALLOCMB MB"
    echo "Unallocated capac. in Volumegroup $vg           : $FREEMB MB"

    # possible output of bdf (mounted/unmounted || wrapped/unwrapped)
    # Filesystem          kbytes    used   avail %used Mounted on
    # /dev/vg00/lvol6     524288   21176  499256    4% /tmp
    # /dev/vg00/lvol5     393216    8592  381624    2%  
    # /dev/vg00-old/lvol3
    #                884736  358328  522384   41% /root/old-lvol3
    # /dev/vg00-old/lvol4                                                      
    #               6569984 4417320 2135848   67%                       
    # if number of fields (NF) eq 1 then get next line
    # check if XX% is last val $NF or next to last $(NF-1)
    # take appropriate values from the end
    # MiMe

    printf "Filesystemcapacity in Volumegroup $vg total     : "
    bdf $(vgdisplay -v $vg | awk '/LV Name/ {print $3}' | sort -u) 2>/dev/null |\
      awk ' NF == 1 || /^Filesystem/ { next }
           $(NF-1) ~ /%$/ { sum=sum+$(NF-4) } 
           $NF     ~ /%$/ { sum=sum+$(NF-3) } 
           END {printf "%ld MB\n", sum/1024 }'
    

    printf "Filesystemcapacity in Volumegroup $vg used      : "
    bdf $(vgdisplay -v $vg | awk '/LV Name/ {print $3}' | sort -u) 2>/dev/null |\
      awk 'NF == 1 || /^Filesystem/  { next }
           $(NF-1) ~ /%$/ { sum=sum+$(NF-3) } 
           $NF     ~ /%$/ { sum=sum+$(NF-2) } 
           END {printf "%ld MB\n", sum/1024 }'
    
    printf "Filesystemcapacity in Volumegroup $vg available : "
    bdf $(vgdisplay -v $vg | awk '/LV Name/ {print $3}' | sort -u) 2>/dev/null |\
      awk 'NF == 1 || /^Filesystem/  { next }
           $(NF-1) ~ /%$/ { sum=sum+$(NF-2) } 
           $NF     ~ /%$/ { sum=sum+$(NF-1) } 
           END {printf "%ld MB\n", sum/1024 }'
    echo "================================================================"

done
