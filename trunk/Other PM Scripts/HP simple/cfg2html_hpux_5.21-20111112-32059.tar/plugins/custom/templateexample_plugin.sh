#!/bin/sh
# ---------------------------------------------------------------------------
# custom example plugin, provided by Andre Naumann, 25. August 2009
# @(#) $Id: templateexample_plugin.sh,v 5.11 2011-07-01 13:43:07 ralproth Exp $
# ---------------------------------------------------------------------------

CFG2HTML_PLUGINTITLE="Example Plugin: This will go into the section title for each plugin"

function cfg2html_plugin {
        echo "Here you can add a shell script, all output to stdout will be added to the"
        echo "cfg2html output file."

		## do something usefull....
        ## echo "The PID of this plugin run was " $$
}

