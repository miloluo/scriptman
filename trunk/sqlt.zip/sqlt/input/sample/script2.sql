VAR b1 CHAR(1);
EXEC :b1 := '1';

select /*+ monitor */
/* ^^unique_id */ v.*,
(orders_total - credit_limit) over_limit
from customer_v v
where orders_total > credit_limit
and customer_type = :b1
order by over_limit desc;
