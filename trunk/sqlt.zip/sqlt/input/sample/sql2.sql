select v.*,
(orders_total - credit_limit) over_limit
from customer_v v
where orders_total > credit_limit
and customer_type = :b1
order by over_limit desc;
