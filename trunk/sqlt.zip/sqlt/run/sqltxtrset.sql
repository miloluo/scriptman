SPO sqltxtrset.log;
SET DEF ON;
SET DEF ^ TERM OFF ECHO ON VER OFF SERVEROUT ON SIZE 1000000 NUMF "" SQLP SQL>;
SET SERVEROUT ON SIZE UNL;
REM
REM $Header: 215187.1 sqltxtrset.sql 11.4.4.7 2012/07/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/run/sqltxtrset.sql
REM
REM DESCRIPTION
REM   Collects SQL tuning diagnostics data and generates a set of
REM   diagnostics files. It inputs a set of SQL_IDs or HASH_VALUEs
REM   of known SQL that are memory resident or pre-captured by AWR.
REM
REM PRE-REQUISITES
REM   1. Execute directly from the sqlt/run directory and not
REM      from some other directory passing path and script name.
REM   2. Use a dedicated SQL*Plus connection (not a shared one).
REM   3. User has been granted SQLT_USER_ROLE.
REM
REM PARAMETERS
REM   1. Comma-separated list of SQL_IDs or HASH_VALUEs of the SQLs
REM      to be extracted (required)
REM   2. SQLTXPLAIN password (required).
REM
REM EXECUTION
REM   1. Execute directly from the sqlt/run directory and not
REM      from some other directory passing path and script name.
REM   2. Start SQL*Plus connecting as the application user of the SQL.
REM   3. Execute script sqltxtrset.sql passing parameter values when
REM      asked.
REM
REM EXAMPLE
REM   # cd sqlt/run
REM   # sqlplus apps
REM   SQL> START sqltxtrset.sql
REM
REM NOTES
REM   1. For possible errors see sqltxtrset.log.
REM   2. For better output execute this script connected as the
REM      application user who issued the SQL.
REM
COL libraries FOR A64;
SELECT SUBSTR(text, INSTR(text, ' ', 1, 3) + 1,  INSTR(text, ' ', 1, 6) - INSTR(text, ' ', 1, 3)) libraries
  FROM all_source
 WHERE owner = 'SQLTXPLAIN'
   AND line = 2
   AND text LIKE '%$Header%'
 ORDER BY 1;
SELECT status||' '||object_type||' '||object_name libraries
  FROM all_objects
 WHERE owner = 'SQLTXPLAIN'
   AND object_type LIKE 'PACKAGE%'
 ORDER BY 1;
COL lib_count NEW_V lib_count FOR 999;
COL role_count NEW_V role_count FOR 999;
SELECT COUNT(*) lib_count FROM all_objects WHERE owner = 'SQLTXPLAIN' AND object_type = 'PACKAGE' AND status = 'VALID';
SELECT COUNT(*) role_count FROM user_role_privs WHERE granted_role IN ('SQLT_USER_ROLE', 'DBA');
SELECT granted_role FROM user_role_privs WHERE granted_role IN ('SQLT_USER_ROLE', 'DBA');
SELECT user FROM dual;
SET TERM ON ECHO OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF ^^role_count. < 1 THEN
    RAISE_APPLICATION_ERROR(-20109, 'User "'||USER||'" lacks required "SQLT_USER_ROLE" role. Request: "GRANT SQLT_USER_ROLE TO '||USER||';" to your DBA.');
  END IF;
  IF ^^lib_count. < 17 THEN
    RAISE_APPLICATION_ERROR(-20110, 'User "'||USER||'" lacks required "SQLT_USER_ROLE" role or SQLT is not properly installed. Review installation NN_*.log files.');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
PRO
PRO WARNING:
PRO ~~~~~~~
PRO Execute sqltxtrset.sql connecting directly from the
PRO sqlt/run directory and not from some other directory.
PRO
PRO You are in this directory:
HOS pwd
PRO
SET VER ON;
PRO
PRO Parameter 1:
PRO Comma-separated list of SQL_IDs or HASH_VALUEs (required)
PRO
DEF list_of_ids = '^1';
PRO
PRO Paremeter 2:
PRO SQLTXPLAIN password (required)
PRO
DEF sqltxplain_password = '^2';
SET TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF '^^sqltxplain_password.' IS NULL THEN
    RAISE_APPLICATION_ERROR(-20104, 'No password specified for user SQLTXPLAIN');
  END IF;
  IF '^^sqltxplain_password.' LIKE '% %' THEN
    RAISE_APPLICATION_ERROR(-20105, 'Password for user SQLTXPLAIN cannot contain spaces');
  END IF;
END;
/
SET TERM ON;
PRO
PRO Value passed to sqltxtrset:
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO LIST_OF_IDS: "^^list_of_ids."
PRO
EXEC DBMS_APPLICATION_INFO.SET_MODULE('sqltxtrset', 'script');
PRO
--
-- begin common
--
SET TERM OFF;
DEF _SQLPLUS_RELEASE
SET FEED OFF VER OFF SHOW OFF HEA ON LIN 1280 NEWP 1 PAGES 960 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF SQLP SQL> BLO . RECSEP OFF APPI OFF SERVEROUT ON SIZE 1000000 FOR WOR;
SET SERVEROUT ON SIZE UNL FOR WOR;
COL connected_user NEW_V connected_user FOR A30;
SELECT user connected_user FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
VAR v_statement_id VARCHAR2(32);
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET TERM ON ECHO OFF;
PRO
PRO NOTE:
PRO If you get one of these errors it means SQLTXPLAIN is not installed:
PRO PLS-00201: identifier 'SQLTXPLAIN.SQLT$A' must be declared
PRO ORA-00904: "SQLTXPLAIN"."SQLT$A"."GET_STATEMENT_ID_C": invalid identifier;
PRO Review NN_*.log files created during installation and fix errors reported.
PRO
EXEC :v_statement_id := sqltxplain.sqlt$a.get_statement_id_c;
CL SCR;
COL sqlt_version FOR A40;
SELECT
'SQLT version number: '||sqltxplain.sqlt$a.get_param('tool_version')||CHR(10)||
'SQLT version date  : '||sqltxplain.sqlt$a.get_param('tool_date')||CHR(10)||
'Installation date  : '||sqltxplain.sqlt$a.get_param('install_date') sqlt_version
FROM DUAL;
PRO
PRO ... please wait ...
SET TERM OFF;
PRINT v_statement_id;
COL statement_id NEW_V statement_id FOR A32;
SELECT :v_statement_id statement_id FROM DUAL;
COL unique_id NEW_V unique_id FOR A32;
SELECT 'sqlt_s'||:v_statement_id unique_id FROM DUAL;
COL libraries FOR A64;
SELECT column_value libraries FROM TABLE(sqltxplain.sqlt$r.libraries_versions);
EXEC sqltxplain.sqlt$a.validate_tool_version('11.4.4.7');
COL install_date FOR A20;
SELECT sqltxplain.sqlt$a.get_param('install_date') install_date FROM DUAL;
COL host_name FOR A80;
SELECT sqltxplain.sqlt$a.get_host_name_short host_name FROM DUAL;
COL udump_path NEW_V udump_path FOR A256;
SELECT sqltxplain.sqlt$a.get_udump_full_path udump_path FROM DUAL;
COL bdump_path NEW_V bdump_path FOR A256;
SELECT sqltxplain.sqlt$a.get_bdump_full_path bdump_path FROM DUAL;
COL user_dump_dest FOR A256;
SELECT sqltxplain.sqlt$a.get_v$parameter('user_dump_dest') user_dump_dest FROM DUAL;
COL background_dump_dest FOR A256;
SELECT sqltxplain.sqlt$a.get_v$parameter('background_dump_dest') background_dump_dest FROM DUAL;
COL directories FOR A256;
WHENEVER SQLERROR CONTINUE;
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
--
-- end common
--
DEF set_id = '^^unique_id.';
VAR v_statement_set_id NUMBER;
EXEC :v_statement_set_id := TO_NUMBER(:v_statement_id);
SET SERVEROUT ON SIZE UNL FOR TRU;
VAR v_list_of_ids VARCHAR2(4000);
BEGIN
  :v_list_of_ids := TRIM(TRANSLATE('^^list_of_ids.',
  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789, ''`~!@#$%^*()-_=+[]{}\|;:".<>/?'||CHR(0)||CHR(9)||CHR(10)||CHR(13)||CHR(38),
  'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz0123456789  '));
END;
/
PRINT v_list_of_ids;
SET TERM ON;
PRO
PRO NOTE:
PRO You used the XTRSET method connected as ^^connected_user..
PRO
PRO WARNING:
PRO ~~~~~~~
PRO Execute sqltxtrset.sql connecting directly from the
PRO sqlt/run directory and not from some other directory.
PRO
PRO You are in this directory:
HOS pwd
PRO
PRO
PRO In case of a session disconnect please verify the following:
PRO 1. There are no errors in sqltxtrset.log.
PRO 2. Your SQLs ^^list_of_ids. exists in memory or in AWR.
PRO 3. You connected as the application user that issued original SQL.
PRO 4. User ^^connected_user. has been granted SQLT_USER_ROLE.
PRO
PRO In case of errors ORA-03113, ORA-03114 or ORA-07445 please just
PRO re-try this SQLT method. This tool handles some of the errors behind
PRO a disconnect when executed a second time.
PRO
PRO To actually diagnose the problem behind the disconnect, read ALERT
PRO log and provide referenced traces to Support. After the root cause
PRO of the disconnect is fixed then reset SQLT corresponding parameter.
PRO
PRO
PRO To monitor progress, login as SQLTXPLAIN into another session and execute:
PRO SQL> SELECT * FROM sqlt$_log_v;;
PRO
PRO ... collecting diagnostics details, please wait ...
PRO
SET TERM OFF ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF SERVEROUT ON SIZE 1000000 FOR TRU;
SPO ^^set_id._driver.sql
DECLARE
  l_first_space INTEGER;
BEGIN
  WHILE :v_list_of_ids IS NOT NULL
  LOOP
    l_first_space := INSTR(:v_list_of_ids||' ', ' ');
    DBMS_OUTPUT.PUT_LINE('@@sqltxtrone.sql '||SUBSTR(:v_list_of_ids, 1, l_first_space - 1));
    :v_list_of_ids := TRIM(SUBSTR(:v_list_of_ids, l_first_space));
  END LOOP;
END;
/
SPO sqltxtrset2.log;
WHENEVER SQLERROR CONTINUE;
SET TERM ON;
PRO Dynamic script ^^set_id._driver.sql must be on same directory than sqltxtrset.sql, sqltxtrone.sql and sqltgetfile.sql.
PRO Execute sqltxtrset.sql directly from the sqlt/run directory and not from some other directory passing path and script name.
PRO Example
PRO # cd sqlt/run
PRO # sqlplus apps
PRO SQL> START sqltxtrset.sql
@@^^set_id._driver.sql
--
SET TERM OFF;
SPO ^^set_id._xtrset.log;
GET sqltxtrset.log
.
GET sqltxtrset2.log
.
SPO OFF;
--
HOS zip -m ^^set_id._set sqltxtrset.log sqltxtrset2.log
HOS zip -d ^^set_id._set sqltxtrset.log sqltxtrset2.log
HOS zip -mT ^^set_id._set ^^set_id._driver.sql ^^set_id._xtrset.log
--
SET TERM ON;
HOS unzip -l ^^set_id._set
PRO File ^^set_id._set.zip has been created. Review ^^set_id._xtrset.log.
SET TERM OFF;
CL COL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(NULL, NULL);
UNDEFINE 1 2 lib_count role_count udump_path bdump_path connected_user statement_id list_of_ids set_id;
UNDEFINE sqltxplain_password;
SET DEF ON TERM ON ECHO OFF FEED 6 VER ON SHOW OFF HEA ON LIN 80 NEWP 1 PAGES 14 SQLC MIX TAB ON TRIMS OFF TI OFF TIMI OFF ARRAY 15 NUMF "" SQLP SQL> SUF sql BLO . RECSEP WR APPI OFF SERVEROUT OFF;
PRO
PRO SQLTXTRSET completed.
