REM $Header: 215187.1 sqltcommon5.sql 11.4.5.0 2012/11/21 carlos.sierra $
-- begin common
PRO
PRO To monitor progress, login into another session and execute:
PRO SQL> SELECT * FROM ^^tool_administer_schema..sqlt$_log_v;;
PRO
PRO ... collecting diagnostics details, please wait ...
PRO
PRO In case of a disconnect review log file in current directory
PRO
SET TERM OFF;
-- end common
