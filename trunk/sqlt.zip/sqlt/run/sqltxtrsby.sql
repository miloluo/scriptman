SPO sqltxtrsby.log;
SET DEF ON;
SET DEF ^ TERM OFF ECHO ON VER OFF SERVEROUT ON SIZE 1000000 NUMF "" SQLP SQL>;
SET SERVEROUT ON SIZE UNL;
REM
REM $Header: 215187.1 sqltxtrsby.sql 11.4.4.7 2012/07/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/run/sqltxtrsby.sql
REM
REM DESCRIPTION
REM   Collects SQL tuning diagnostics data and generates a set of
REM   diagnostics files. It inputs one SQL_ID or HASH_VALUE of a
REM   known SQL that is memory resident or pre-captured by AWR in
REM   a stand-by read-only database.
REM
REM PRE-REQUISITES
REM   1. Use a dedicated SQL*Plus connection (not a shared one).
REM   2. User has been granted SQLT_USER_ROLE.
REM   3. There exists a dblink connection into SQLTXPLAIN in the
REM      stand-by database.
REM
REM PARAMETERS
REM   1. SQL_ID or HASH_VALUE of the SQL to be extracted (required)
REM   2. DBLINK to SQLTXPLAIN in stand-by database (required)
REM   3. Local SQLTXPLAIN password (required)
REM
REM EXECUTION
REM   1. Navigate to sqlt main directory.
REM   2. Start SQL*Plus connecting as a user that can access the
REM      dblink into SQLTXPLAIN in stand-by read-only database.
REM   3. Execute script sqltxtrsby.sql passing first SQL_ID or
REM      HASH_VALUE of the one SQL. This SQL must be memory resident
REM      or pre-captured by AWR.
REM   4. Pass also the DBLINK to access the stand-by database.
REM   5. Enter SQLTXPLAIN password when asked for it.
REM
REM EXAMPLE
REM   # cd sqlt
REM   # sqlplus apps
REM   SQL> START [path]sqltxtrsby.sql [SQL_ID]|[HASH_VALUE] [DBLINK]
REM   SQL> START run/sqltxtrsby.sql 0w6uydn50g8cx V1123
REM   SQL> START run/sqltxtrsby.sql 2524255098 V1123
REM
REM NOTES
REM   1. For possible errors see sqltxtrsby.log.
REM
COL libraries FOR A64;
SELECT SUBSTR(text, INSTR(text, ' ', 1, 3) + 1,  INSTR(text, ' ', 1, 6) - INSTR(text, ' ', 1, 3)) libraries
  FROM all_source
 WHERE owner = 'SQLTXPLAIN'
   AND line = 2
   AND text LIKE '%$Header%'
 ORDER BY 1;
SELECT status||' '||object_type||' '||object_name libraries
  FROM all_objects
 WHERE owner = 'SQLTXPLAIN'
   AND object_type LIKE 'PACKAGE%'
 ORDER BY 1;
COL lib_count NEW_V lib_count FOR 999;
COL role_count NEW_V role_count FOR 999;
SELECT COUNT(*) lib_count FROM all_objects WHERE owner = 'SQLTXPLAIN' AND object_type = 'PACKAGE' AND status = 'VALID';
SELECT COUNT(*) role_count FROM user_role_privs WHERE granted_role IN ('SQLT_USER_ROLE', 'DBA');
SELECT granted_role FROM user_role_privs WHERE granted_role IN ('SQLT_USER_ROLE', 'DBA');
SELECT user FROM dual;
SET TERM ON ECHO OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF ^^role_count. < 1 THEN
    RAISE_APPLICATION_ERROR(-20109, 'User "'||USER||'" lacks required "SQLT_USER_ROLE" role. Request: "GRANT SQLT_USER_ROLE TO '||USER||';" to your DBA.');
  END IF;
  IF ^^lib_count. < 17 THEN
    RAISE_APPLICATION_ERROR(-20110, 'User "'||USER||'" lacks required "SQLT_USER_ROLE" role or SQLT is not properly installed. Review installation NN_*.log files.');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
PRO
PRO Parameter 1:
PRO SQL_ID or HASH_VALUE of the SQL to be extracted (required)
PRO
DEF sql_id_or_hash_value_1 = '^1';
PRO
PRO Parameter 2:
PRO DBLINK to SQLTXPLAIN in the stand-by database (required)
PRO
DEF db_link_1 = '^2';
PRO
SET TERM OFF;
COL sql_id_or_hash_value NEW_V sql_id_or_hash_value;
SELECT TRIM('^^sql_id_or_hash_value_1.') sql_id_or_hash_value FROM DUAL;
COL db_link NEW_V db_link;
SELECT '@'||REPLACE(REPLACE('^^db_link_1.', ' '), '@') db_link FROM DUAL;
SET TERM ON;
PRO Paremeter 3:
PRO SQLTXPLAIN password (required)
PRO
DEF sqltxplain_password = '^3';
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF '^^sqltxplain_password.' IS NULL THEN
    RAISE_APPLICATION_ERROR(-20104, 'No password specified for user SQLTXPLAIN');
  END IF;
  IF '^^sqltxplain_password.' LIKE '% %' THEN
    RAISE_APPLICATION_ERROR(-20105, 'Password for user SQLTXPLAIN cannot contain spaces');
  END IF;
END;
/
PRO
PRO Values passed to sqltxtrsby:
PRO ~~~~~~~~~~~~~~~~~~~~~~~~~~~
PRO SQL_ID_OR_HASH_VALUE: "^^sql_id_or_hash_value."
PRO DB_LINK             : "^^db_link."
PRO
EXEC DBMS_APPLICATION_INFO.SET_MODULE('sqltxtrsby', 'script');
PRO
--
-- begin common
--
SET TERM OFF;
DEF _SQLPLUS_RELEASE
SET FEED OFF VER OFF SHOW OFF HEA ON LIN 1280 NEWP 1 PAGES 960 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF SQLP SQL> BLO . RECSEP OFF APPI OFF SERVEROUT ON SIZE 1000000 FOR WOR;
SET SERVEROUT ON SIZE UNL FOR WOR;
COL connected_user NEW_V connected_user FOR A30;
SELECT user connected_user FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
VAR v_statement_id VARCHAR2(32);
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET TERM ON ECHO OFF;
PRO
PRO NOTE:
PRO If you get one of these errors it means SQLTXPLAIN is not installed:
PRO PLS-00201: identifier 'SQLTXPLAIN.SQLT$A' must be declared
PRO ORA-00904: "SQLTXPLAIN"."SQLT$A"."GET_STATEMENT_ID_C": invalid identifier;
PRO Review NN_*.log files created during installation and fix errors reported.
PRO
EXEC :v_statement_id := sqltxplain.sqlt$a.get_statement_id_c;
EXEC sqltxplain.sqlt$a.trace_on(:v_statement_id);
CL SCR;
COL sqlt_version FOR A40;
SELECT
'SQLT version number: '||sqltxplain.sqlt$a.get_param('tool_version')||CHR(10)||
'SQLT version date  : '||sqltxplain.sqlt$a.get_param('tool_date')||CHR(10)||
'Installation date  : '||sqltxplain.sqlt$a.get_param('install_date') sqlt_version
FROM DUAL;
PRO
PRO ... please wait ...
SET TERM OFF;
PRINT v_statement_id;
COL statement_id NEW_V statement_id FOR A32;
SELECT :v_statement_id statement_id FROM DUAL;
COL unique_id NEW_V unique_id FOR A32;
SELECT 'sqlt_s'||:v_statement_id unique_id FROM DUAL;
COL libraries FOR A64;
SELECT column_value libraries FROM TABLE(sqltxplain.sqlt$r.libraries_versions);
EXEC sqltxplain.sqlt$a.validate_tool_version('11.4.4.7');
COL install_date FOR A20;
SELECT sqltxplain.sqlt$a.get_param('install_date') install_date FROM DUAL;
COL host_name FOR A80;
SELECT sqltxplain.sqlt$a.get_host_name_short host_name FROM DUAL;
COL udump_path NEW_V udump_path FOR A256;
SELECT sqltxplain.sqlt$a.get_udump_full_path udump_path FROM DUAL;
COL bdump_path NEW_V bdump_path FOR A256;
SELECT sqltxplain.sqlt$a.get_bdump_full_path bdump_path FROM DUAL;
COL user_dump_dest FOR A256;
SELECT sqltxplain.sqlt$a.get_v$parameter('user_dump_dest') user_dump_dest FROM DUAL;
COL background_dump_dest FOR A256;
SELECT sqltxplain.sqlt$a.get_v$parameter('background_dump_dest') background_dump_dest FROM DUAL;
COL directories FOR A256;
WHENEVER SQLERROR CONTINUE;
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
EXEC sqltxplain.sqlt$a.reset_directories;
--
-- end common
--
SET TERM ON;
PRO
PRO NOTE:
PRO You used the XTRSBY method connected as ^^connected_user..
PRO
PRO In case of a session disconnect please verify the following:
PRO 1. There are no errors in sqltxtrsby.log.
PRO 2. Your SQL ^^sql_id_or_hash_value. exists in memory or in AWR.
PRO 3. You connected as the application user that issued original SQL.
PRO 4. User ^^connected_user. has been granted SQLT_USER_ROLE.
PRO
PRO In case of errors ORA-03113, ORA-03114 or ORA-07445 please just
PRO re-try this SQLT method. This tool handles some of the errors behind
PRO a disconnect when executed a second time.
PRO
PRO To actually diagnose the problem behind the disconnect, read ALERT
PRO log and provide referenced traces to Support. After the root cause
PRO of the disconnect is fixed then reset SQLT corresponding parameter.
PRO
PRO To monitor progress, login as SQLTXPLAIN into another session and execute:
PRO SQL> SELECT * FROM sqlt$_log_v;;
PRO
PRO ... collecting diagnostics details, please wait ...
PRO
PRO In case of a disconnect review sqltxtrsby.log
PRO
EXEC sqltxplain.sqlt$i.xtrsby(p_statement_id => :v_statement_id, p_sql_id_or_hash_value => '^^sql_id_or_hash_value.', p_stand_by_dblink => '^^db_link.', p_password => 'Y');
WHENEVER SQLERROR CONTINUE;
SET TERM OFF ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF SERVEROUT ON SIZE 1000000 FOR TRU;
SET SERVEROUT ON SIZE UNL FOR TRU;
PRO No fatal errors!
COL column_value FOR A2000;
COL filename NEW_V filename FOR A256;
SPO OFF;
-- consumed by xtrcxec.sql:
DEF zipfile1 = '^^unique_id.';
--
-- begin common
--
HOS vmstat 5 5 >> sqltxhost.log
HOS sar -u 5 5 >> sqltxhost.log
@@sqltgetfile.sql SQL_MONITOR_DRIVER
@^^filename.
@@sqltgetfile.sql REMOTE_DRIVER
@^^filename.
@@sqltgetfile.sql MAIN_REPORT
@@sqltgetfile.sql LITE_REPORT
@@sqltgetfile.sql README_REPORT_HTML
@@sqltgetfile.sql README_REPORT_TXT
@@sqltgetfile.sql METADATA_SCRIPT
@@sqltgetfile.sql SYSTEM_STATS_SCRIPT
@@sqltgetfile.sql SET_CBO_ENV_SCRIPT
@@sqltgetfile.sql CUSTOM_SQL_PROFILE
@@sqltgetfile.sql STA_REPORT_MEM
@@sqltgetfile.sql STA_SCRIPT_MEM
@@sqltgetfile.sql STA_REPORT_TXT
@@sqltgetfile.sql STA_SCRIPT_TXT
@@sqltgetfile.sql STA_REPORT_AWR
@@sqltgetfile.sql STA_SCRIPT_AWR
@@sqltgetfile.sql SQL_DETAIL_ACTIVE
@@sqltgetfile.sql SQL_MONITOR_ACTIVE
@@sqltgetfile.sql SQL_MONITOR_HTML
@@sqltgetfile.sql SQL_MONITOR_TEXT
@@sqltgetfile.sql 10053_EXPLAIN
@@sqltgetfile.sql 10053_EXTRACT
@@sqltgetfile.sql BDE_CHK_CBO_REPORT
@@sqltgetfile.sql IMPORT_SCRIPT
@@sqltgetfile.sql EXPORT_PARFILE
@@sqltgetfile.sql PLAN
@@sqltgetfile.sql 10053
@@sqltgetfile.sql FLUSH
@@sqltgetfile.sql PURGE
@@sqltgetfile.sql RESTORE
@@sqltgetfile.sql DEL_HGRM
@@sqltgetfile.sql TC_SQL
@@sqltgetfile.sql XPRESS_SH
@@sqltgetfile.sql XPRESS_SQL
@@sqltgetfile.sql SETUP
@@sqltgetfile.sql README
@@sqltgetfile.sql TC_PKG
@@sqltgetfile.sql SEL
@@sqltgetfile.sql SEL_AUX
@@sqltgetfile.sql AWRRPT_DRIVER
@^^filename.
@@sqltgetfile.sql ADDMRPT_DRIVER
@^^filename.
@@sqltgetfile.sql ASHRPT_DRIVER
@^^filename.
@@sqltgetfile.sql TCB_DRIVER
@^^filename.
@@sqltgetfile.sql EXPORT_DRIVER
@^^filename.
--
-- end common
--
@@sqltgetfile.sql TEST_CASE_SQL
@@sqltgetfile.sql Q
@@sqltgetfile.sql TEST_CASE_SCRIPT
-- consumed by xtrcxec.sql:
DEF tcscript = '^^filename.';
SPO ^^unique_id._xtrsby.log;
GET sqltxtrsby.log
.
SPO OFF;
--
-- begin common
--
EXEC sqltxplain.sqlt$a.trace_off;
HOS tkprof ^^udump_path.*_ora_*_S^^statement_id._SQLT_TRACE.trc ^^unique_id._sqlt_tkprof_nosort.txt >> sqltxhost.log
HOS tkprof ^^udump_path.*_ora_*_S^^statement_id._SQLT_TRACE.trc ^^unique_id._sqlt_tkprof_sort.txt sort=prsela exeela fchela >> sqltxhost.log
HOS zip -mT ^^unique_id._log ^^unique_id._sqlt_tkprof_*.txt >> sqltxhost.log
--
HOS zip -jT ^^unique_id._opatch $ORACLE_HOME/cfgtoollogs/opatch/opatch* >> sqltxhost.log
HOS unzip -l ^^unique_id._opatch >> sqltxhost.log
--
HOS chmod 777 xpress.sh
HOS zip -mT ^^unique_id._tc ^^unique_id._system_stats.sql ^^unique_id._metadata.sql ^^unique_id._set_cbo_env.sql ^^unique_id._readme.txt >> sqltxhost.log
HOS zip -mT ^^unique_id._tc q.sql plan.sql 10053.sql flush.sql tc.sql xpress.sql xpress.sh setup.sql readme.txt tc_pkg.sql sel.sql sel_aux.sql >> sqltxhost.log
HOS zip -mT ^^unique_id._tc ^^unique_id._purge.sql ^^unique_id._restore.sql ^^unique_id._del_hgrm.sql >> sqltxhost.log
HOS zip -jT ^^unique_id._tc ^^unique_id._opatch.zip >> sqltxhost.log
HOS unzip -l ^^unique_id._tc >> sqltxhost.log
--
HOS zip -juT ^^unique_id._trc ^^udump_path.*_s^^statement_id._*.trc >> sqltxhost.log
HOS zip -juT ^^unique_id._trc ^^bdump_path.*_s^^statement_id._*.trc >> sqltxhost.log
HOS unzip -l ^^unique_id._trc >> sqltxhost.log
--
-- end common
--
HOS zip -m ^^unique_id._xtrsby_^^sql_id_or_hash_value. sqltxtrsby.log sqltxtrsby2.log missing_file.txt >> sqltxhost.log
HOS zip -d ^^unique_id._xtrsby_^^sql_id_or_hash_value. sqltxtrsby.log sqltxtrsby2.log missing_file.txt >> sqltxhost.log
--
-- begin common
--
HOS unzip -l ^^unique_id._xtrsby_^^sql_id_or_hash_value. >> sqltxhost.log
--
HOS echo "SIEBEL_ORA_BIND_PEEK" >> sqltxhost.log
HOS echo $SIEBEL_ORA_BIND_PEEK >> sqltxhost.log
HOS echo "ORACLE_HOME" >> sqltxhost.log
HOS echo $ORACLE_HOME >> sqltxhost.log
HOS echo "NLS_LANG" >> sqltxhost.log
HOS echo $NLS_LANG >> sqltxhost.log
HOS echo "UDUMP" >> sqltxhost.log
HOS ls -dl ^^udump_path. >> sqltxhost.log
HOS echo "BDUMP" >> sqltxhost.log
HOS ls -dl ^^bdump_path. >> sqltxhost.log
HOS echo "WHO" >> sqltxhost.log
HOS who >> sqltxhost.log
--
-- end common
--
HOS zip -mT ^^unique_id._log ^^unique_id._xtrsby.log sqltxhost.log
HOS zip -mT ^^unique_id._xtrsby_^^sql_id_or_hash_value. ^^unique_id.*
--
SET TERM ON;
HOS unzip -l ^^unique_id._xtrsby_^^sql_id_or_hash_value.
PRO File ^^unique_id._xtrsby_^^sql_id_or_hash_value..zip for ^^sql_id_or_hash_value. has been created.
SET TERM OFF;
CL COL;
EXEC DBMS_APPLICATION_INFO.SET_MODULE(NULL, NULL);
UNDEFINE 1 2 3 lib_count role_count udump_path bdump_path connected_user statement_id unique_id filename;
UNDEFINE sql_id_or_hash_value db_link sql_id_or_hash_value_1 db_link_1 sqltxplain_password;
SET DEF ON TERM ON ECHO OFF FEED 6 VER ON SHOW OFF HEA ON LIN 80 NEWP 1 PAGES 14 SQLC MIX TAB ON TRIMS OFF TI OFF TIMI OFF ARRAY 15 NUMF "" SQLP SQL> SUF sql BLO . RECSEP WR APPI OFF SERVEROUT OFF;
PRO
PRO SQLTXTRSBY completed.
