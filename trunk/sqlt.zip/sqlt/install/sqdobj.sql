SET ECHO ON TERM OFF;
REM
REM $Header: 215187.1 sqdobj.sql 11.4.4.7 2012/07/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqdobj.sql
REM
REM DESCRIPTION
REM   Drops current SQLTXPLAIN schema objects from SQLT tool.
REM
REM PRE-REQUISITES
REM   1. To drop current SQLTXPLAIN objects you must connect
REM      INTERNAL(SYS) as SYSDBA, or as SQLTXPLAIN.
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting INTERNAL(SYS) as SYSDBA
REM      or as SQLTXPLAIN
REM   3. Execute this script sqdobj.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqdobj.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqdrop.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common

SET ECHO OFF TERM ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER NOT IN ('SYS', 'SQLTXPLAIN') THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop of current SQLTXPLAIN objects failed. Connect as SYS or SQLTXPLAIN, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET ECHO ON TERM OFF;

/* - packages - */
DROP PACKAGE BODY sqltxplain.sqlt$a;
DROP PACKAGE BODY sqltxplain.sqlt$c;
DROP PACKAGE BODY sqltxplain.sqlt$d;
DROP PACKAGE BODY sqltxplain.sqlt$e;
DROP PACKAGE BODY sqltxplain.sqlt$h;
DROP PACKAGE BODY sqltxplain.sqlt$i;
DROP PACKAGE BODY sqltxplain.sqlt$m;
DROP PACKAGE BODY sqltxplain.sqlt$s;
DROP PACKAGE BODY sqltxplain.sqlt$r;
DROP PACKAGE BODY sqltxplain.sqlt$t;
DROP PACKAGE      sqltxplain.sqlt$a;
DROP PACKAGE      sqltxplain.sqlt$c;
DROP PACKAGE      sqltxplain.sqlt$d;
DROP PACKAGE      sqltxplain.sqlt$e;
DROP PACKAGE      sqltxplain.sqlt$h;
DROP PACKAGE      sqltxplain.sqlt$i;
DROP PACKAGE      sqltxplain.sqlt$m;
DROP PACKAGE      sqltxplain.sqlt$r;
DROP PACKAGE      sqltxplain.sqlt$s;
DROP PACKAGE      sqltxplain.sqlt$t;

/* - sys views created and used by sqlt - */
DROP VIEW sys.sqlt$_col$_v;
DROP VIEW sys.sqlt$_dba_col_stats_vers_v;
DROP VIEW sys.sqlt$_dba_col_usage_v;
DROP VIEW sys.sqlt$_dba_hgrm_stats_vers_v;
DROP VIEW sys.sqlt$_dba_ind_stats_vers_v;
DROP VIEW sys.sqlt$_dba_tab_stats_vers_v;
DROP VIEW sys.sqlt$_gv$parameter_cbo_v;
DROP VIEW sys.sqlt$_my_v$session;
DROP VIEW sys.sqlt$_my_v$sql;

/* - views - */
DROP VIEW sqltxplain.sqlt$_captured_binds_sum_v;
DROP VIEW sqltxplain.sqlt$_captured_binds_v;
DROP VIEW sqltxplain.sqlt$_dba_act_sess_hist_p;
DROP VIEW sqltxplain.sqlt$_dba_act_sess_hist_pl;
DROP VIEW sqltxplain.sqlt$_dba_all_table_cols_v;
DROP VIEW sqltxplain.sqlt$_dba_all_tables_v;
DROP VIEW sqltxplain.sqlt$_dba_col_stats_versions_v;
DROP VIEW sqltxplain.sqlt$_dba_hist_sqlstat_v;
DROP VIEW sqltxplain.sqlt$_dba_ind_columns_v;
DROP VIEW sqltxplain.sqlt$_dba_ind_statistics_v;
DROP VIEW sqltxplain.sqlt$_dba_ind_stats_versions_v;
DROP VIEW sqltxplain.sqlt$_dba_indexes_v;
DROP VIEW sqltxplain.sqlt$_dba_stat_extensions_v;
DROP VIEW sqltxplain.sqlt$_dba_tab_col_statistics_v;
DROP VIEW sqltxplain.sqlt$_dba_tab_histograms_v;
DROP VIEW sqltxplain.sqlt$_dba_tab_statistics_v;
DROP VIEW sqltxplain.sqlt$_dba_tab_stats_versions_v;
DROP VIEW sqltxplain.sqlt$_dependencies_v;
DROP VIEW sqltxplain.sqlt$_gv$act_sess_hist_p;
DROP VIEW sqltxplain.sqlt$_gv$act_sess_hist_pl;
DROP VIEW sqltxplain.sqlt$_gv$object_dependency_v;
DROP VIEW sqltxplain.sqlt$_gv$pq_sysstat_v;
DROP VIEW sqltxplain.sqlt$_gv$px_process_sysstat_v;
DROP VIEW sqltxplain.sqlt$_gv$px_sesstat_v;
DROP VIEW sqltxplain.sqlt$_gv$segment_statistics_v;
DROP VIEW sqltxplain.sqlt$_gv$session_event_v;
DROP VIEW sqltxplain.sqlt$_gv$sesstat_v;
DROP VIEW sqltxplain.sqlt$_log_v;
DROP VIEW sqltxplain.sqlt$_peeked_binds_sum_v;
DROP VIEW sqltxplain.sqlt$_peeked_binds_v;
DROP VIEW sqltxplain.sqlt$_plan_statistics_v;
DROP VIEW sqltxplain.sqlt$_plan_stats_v;
DROP VIEW sqltxplain.sqlt$_plan_summary_v2;
DROP VIEW sqltxplain.sqlt$_plan_summary_v;
DROP VIEW sqltxplain.sqlt$_sql_profile_hints_v;
DROP VIEW sqltxplain.sqlt$_sql_shared_cursor_v;
DROP VIEW sqltxplain.sqlt$_wri$_optstat_aux_hist_v;

/* - tables - */
DROP TABLE sqltxplain.chk$cbo$parameter_apps;
DROP TABLE sqltxplain.sqlg$_clob;
DROP TABLE sqltxplain.sqlg$_column_html_table;
DROP TABLE sqltxplain.sqlg$_column_predicate;
DROP TABLE sqltxplain.sqlg$_observation;
DROP TABLE sqltxplain.sqlg$_sql_shared_cursor_n;
DROP TABLE sqltxplain.sqlg$_temp;
DROP TABLE sqltxplain.sqli$_clob;
DROP TABLE sqltxplain.sqli$_db_link;
DROP TABLE sqltxplain.sqli$_file;
DROP TABLE sqltxplain.sqli$_parameter;
DROP TABLE sqltxplain.sqli$_sess_parameter;
DROP TABLE sqltxplain.sqli$_stattab_temp;
DROP TABLE sqltxplain.sqli$_stgtab_sqlprof;
DROP TABLE sqltxplain.sqli$_stgtab_sqlset;
DROP TABLE sqltxplain.sqlt$_aux_stats$;
DROP TABLE sqltxplain.sqlt$_dba_audit_policies;
DROP TABLE sqltxplain.sqlt$_dba_autotask_client;
DROP TABLE sqltxplain.sqlt$_dba_col_stats_versions;
DROP TABLE sqltxplain.sqlt$_dba_col_usage$;
DROP TABLE sqltxplain.sqlt$_dba_constraints;
DROP TABLE sqltxplain.sqlt$_dba_dependencies;
DROP TABLE sqltxplain.sqlt$_dba_hist_active_sess_his;
DROP TABLE sqltxplain.sqlt$_dba_hist_parameter;
DROP TABLE sqltxplain.sqlt$_dba_hist_parameter_m;
DROP TABLE sqltxplain.sqlt$_dba_hist_seg_stat_obj;
DROP TABLE sqltxplain.sqlt$_dba_hist_snapshot;
DROP TABLE sqltxplain.sqlt$_dba_hist_sql_plan;
DROP TABLE sqltxplain.sqlt$_dba_hist_sqlbind;
DROP TABLE sqltxplain.sqlt$_dba_hist_sqlstat;
DROP TABLE sqltxplain.sqlt$_dba_hist_sqltext;
DROP TABLE sqltxplain.sqlt$_dba_histgrm_stats_versn;
DROP TABLE sqltxplain.sqlt$_dba_ind_columns;
DROP TABLE sqltxplain.sqlt$_dba_ind_expressions;
DROP TABLE sqltxplain.sqlt$_dba_ind_partitions;
DROP TABLE sqltxplain.sqlt$_dba_ind_statistics;
DROP TABLE sqltxplain.sqlt$_dba_ind_stats_versions;
DROP TABLE sqltxplain.sqlt$_dba_ind_subpartitions;
DROP TABLE sqltxplain.sqlt$_dba_indexes;
DROP TABLE sqltxplain.sqlt$_dba_nested_table_cols;
DROP TABLE sqltxplain.sqlt$_dba_nested_tables;
DROP TABLE sqltxplain.sqlt$_dba_object_tables;
DROP TABLE sqltxplain.sqlt$_dba_objects;
DROP TABLE sqltxplain.sqlt$_dba_optstat_operations;
DROP TABLE sqltxplain.sqlt$_dba_outline_hints;
DROP TABLE sqltxplain.sqlt$_dba_outlines;
DROP TABLE sqltxplain.sqlt$_dba_part_col_statistics;
DROP TABLE sqltxplain.sqlt$_dba_part_histograms;
DROP TABLE sqltxplain.sqlt$_dba_part_key_columns;
DROP TABLE sqltxplain.sqlt$_dba_policies;
DROP TABLE sqltxplain.sqlt$_dba_scheduler_jobs;
DROP TABLE sqltxplain.sqlt$_dba_segments;
DROP TABLE sqltxplain.sqlt$_dba_source;
DROP TABLE sqltxplain.sqlt$_dba_sql_plan_baselines;
DROP TABLE sqltxplain.sqlt$_dba_sql_profiles;
DROP TABLE sqltxplain.sqlt$_dba_sqltune_plans;
DROP TABLE sqltxplain.sqlt$_dba_stat_extensions;
DROP TABLE sqltxplain.sqlt$_dba_subpart_col_stats;
DROP TABLE sqltxplain.sqlt$_dba_subpart_histograms;
DROP TABLE sqltxplain.sqlt$_dba_tab_col_statistics;
DROP TABLE sqltxplain.sqlt$_dba_tab_cols;
DROP TABLE sqltxplain.sqlt$_dba_tab_histograms;
DROP TABLE sqltxplain.sqlt$_dba_tab_modifications;
DROP TABLE sqltxplain.sqlt$_dba_tab_partitions;
DROP TABLE sqltxplain.sqlt$_dba_tab_statistics;
DROP TABLE sqltxplain.sqlt$_dba_tab_stats_versions;
DROP TABLE sqltxplain.sqlt$_dba_tab_subpartitions;
DROP TABLE sqltxplain.sqlt$_dba_tables;
DROP TABLE sqltxplain.sqlt$_dba_tablespaces;
DROP TABLE sqltxplain.sqlt$_dbms_xplan;
DROP TABLE sqltxplain.sqlt$_gv$active_session_histor;
DROP TABLE sqltxplain.sqlt$_gv$nls_parameters;
DROP TABLE sqltxplain.sqlt$_gv$object_dependency;
DROP TABLE sqltxplain.sqlt$_gv$parameter2;
DROP TABLE sqltxplain.sqlt$_gv$parameter_cbo;
DROP TABLE sqltxplain.sqlt$_gv$pq_sesstat;
DROP TABLE sqltxplain.sqlt$_gv$pq_slave;
DROP TABLE sqltxplain.sqlt$_gv$pq_sysstat;
DROP TABLE sqltxplain.sqlt$_gv$pq_tqstat;
DROP TABLE sqltxplain.sqlt$_gv$px_instance_group;
DROP TABLE sqltxplain.sqlt$_gv$px_process;
DROP TABLE sqltxplain.sqlt$_gv$px_process_sysstat;
DROP TABLE sqltxplain.sqlt$_gv$px_session;
DROP TABLE sqltxplain.sqlt$_gv$px_sesstat;
DROP TABLE sqltxplain.sqlt$_gv$segment_statistics;
DROP TABLE sqltxplain.sqlt$_gv$session_event;
DROP TABLE sqltxplain.sqlt$_gv$sesstat;
DROP TABLE sqltxplain.sqlt$_gv$sql;
DROP TABLE sqltxplain.sqlt$_gv$sql_bind_capture;
DROP TABLE sqltxplain.sqlt$_gv$sql_cs_histogram;
DROP TABLE sqltxplain.sqlt$_gv$sql_cs_selectivity;
DROP TABLE sqltxplain.sqlt$_gv$sql_cs_statistics;
DROP TABLE sqltxplain.sqlt$_gv$sql_monitor;
DROP TABLE sqltxplain.sqlt$_gv$sql_optimizer_env;
DROP TABLE sqltxplain.sqlt$_gv$sql_plan;
DROP TABLE sqltxplain.sqlt$_gv$sql_plan_monitor;
DROP TABLE sqltxplain.sqlt$_gv$sql_plan_statistics;
DROP TABLE sqltxplain.sqlt$_gv$sql_shared_cursor;
DROP TABLE sqltxplain.sqlt$_gv$sql_workarea;
DROP TABLE sqltxplain.sqlt$_gv$sqlarea;
DROP TABLE sqltxplain.sqlt$_gv$sqlarea_plan_hash;
DROP TABLE sqltxplain.sqlt$_gv$sqlstats;
DROP TABLE sqltxplain.sqlt$_gv$sqlstats_plan_hash;
DROP TABLE sqltxplain.sqlt$_gv$sqltext_with_newlines;
DROP TABLE sqltxplain.sqlt$_gv$statname;
DROP TABLE sqltxplain.sqlt$_gv$system_parameter;
DROP TABLE sqltxplain.sqlt$_gv$vpd_policy;
DROP TABLE sqltxplain.sqlt$_ind_columns;
DROP TABLE sqltxplain.sqlt$_indexes;
DROP TABLE sqltxplain.sqlt$_log;
DROP TABLE sqltxplain.sqlt$_metadata;
DROP TABLE sqltxplain.sqlt$_nls_database_parameters;
DROP TABLE sqltxplain.sqlt$_optstat_user_prefs$;
DROP TABLE sqltxplain.sqlt$_outline_data;
DROP TABLE sqltxplain.sqlt$_parameter2;
DROP TABLE sqltxplain.sqlt$_peeked_binds;
DROP TABLE sqltxplain.sqlt$_plan_extension;
DROP TABLE sqltxplain.sqlt$_plan_info;
DROP TABLE sqltxplain.sqlt$_plan_table;
DROP TABLE sqltxplain.sqlt$_sql_plan_table;
DROP TABLE sqltxplain.sqlt$_sql_shared_cursor_d;
DROP TABLE sqltxplain.sqlt$_sql_statement;
DROP TABLE sqltxplain.sqlt$_sqlobj$;
DROP TABLE sqltxplain.sqlt$_sqlobj$data;
DROP TABLE sqltxplain.sqlt$_sqlprof$;
DROP TABLE sqltxplain.sqlt$_sqlprof$attr;
DROP TABLE sqltxplain.sqlt$_statement;
DROP TABLE sqltxplain.sqlt$_stattab;
DROP TABLE sqltxplain.sqlt$_stgtab_baseline;
DROP TABLE sqltxplain.sqlt$_stgtab_sqlprof;
DROP TABLE sqltxplain.sqlt$_stgtab_sqlset;
DROP TABLE sqltxplain.sqlt$_tab_columns;
DROP TABLE sqltxplain.sqlt$_v$session_fix_control;
DROP TABLE sqltxplain.sqlt$_wri$_adv_rationale;
DROP TABLE sqltxplain.sqlt$_wri$_adv_tasks;
DROP TABLE sqltxplain.sqlt$_wri$_optstat_aux_history;

/* - sequences - */
DROP SEQUENCE sqltxplain.sqlt$_sql_statement_id_s;

SET ECHO OFF TERM ON;
PRO
PRO SQDOBJ completed. Ignore errors from this script
