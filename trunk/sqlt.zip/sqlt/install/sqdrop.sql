SPO 00_sqdrop.log;
SET TERM OFF ECHO ON;
REM
REM $Header: 215187.1 sqdrop.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqdrop.sql
REM
REM DESCRIPTION
REM   Uninstalls the SQLT tool and drops its schema owner SQLTXPLAIN.
REM
REM PRE-REQUISITES
REM   1. To uninstall SQLT you must connect INTERNAL(SYS) as SYSDBA.
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory.
REM   2. Start SQL*Plus connecting INTERNAL(SYS) as SYSDBA.
REM   3. Execute script sqdrop.sql.
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqdrop.sql
REM
REM NOTES
REM   1. You can reinstall SQLT after this script completes.
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF;
DEF tool_owner = SQLTXPLAIN
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Uninstall of SQLT failed. Connect as SYS, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET TERM ON;
PRO ... uninstalling SQLT, please wait
SET TERM OFF;
-- drops TRCA objects owned by SQLT
@@tadobj.sql
-- drops old objects not used by this version of SQLT
@@sqdold.sql
-- drops objects used by this version of SQLT
@@sqdobj.sql
-- drops SQLT role and user
@@sqdusr.sql
SET ECHO OFF;
UNDEFINE tool_owner
PRO
PRO SQDROP completed.
SPO OFF;
