SET ECHO ON TERM OFF;
REM
REM $Header: 224270.1 tadobj.sql 11.4.2.5 2011/03/20 csierra $
REM
REM Copyright (c) 2000-2011, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   tadobj.sql
REM
REM DESCRIPTION
REM   This script drops existing TRCANLZR objects.
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA or as TRCANLZR
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to trca/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA or as
REM      TRCANLZR
REM   3. Execute script tadobj.sql
REM
REM EXAMPLE
REM   # cd trca/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start tadobj.sql
REM
REM NOTES
REM   1. This script is executed automatically by tadrop.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER NOT IN ('SYS', 'TRCANLZR', 'SQLTXPLAIN') THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop script failed - tadobj.sql should be executed connected as SYS, TRCANLZR or SQLTXPLAIN, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET ECHO ON;

-- package bodies
DROP PACKAGE BODY &&tool_owner..trca$g;
DROP PACKAGE BODY &&tool_owner..trca$i;
DROP PACKAGE BODY &&tool_owner..trca$e;
DROP PACKAGE BODY &&tool_owner..trca$p;
DROP PACKAGE BODY &&tool_owner..trca$r;
DROP PACKAGE BODY &&tool_owner..trca$t;
DROP PACKAGE BODY &&tool_owner..trca$x;

-- views
DROP VIEW &&tool_owner..trca$_call_vf;
DROP VIEW &&tool_owner..trca$_dba_extents;
DROP VIEW &&tool_owner..trca$_dba_extents_p;
DROP VIEW &&tool_owner..trca$_dba_segments;
DROP VIEW &&tool_owner..trca$_dba_segments_p;
DROP VIEW &&tool_owner..trca$_error_vf;
DROP VIEW &&tool_owner..trca$_exec_binds_vf;
DROP VIEW &&tool_owner..trca$_exec_v;
DROP VIEW &&tool_owner..trca$_exec_vf;
DROP VIEW &&tool_owner..trca$_gap_call_vf;
DROP VIEW &&tool_owner..trca$_gap_vf;
DROP VIEW &&tool_owner..trca$_group_indexes_v;
DROP VIEW &&tool_owner..trca$_group_tables_v;
DROP VIEW &&tool_owner..trca$_group_v;
DROP VIEW &&tool_owner..trca$_hot_block_segment_vf;
DROP VIEW &&tool_owner..trca$_ind_columns_v;
DROP VIEW &&tool_owner..trca$_log_v;
DROP VIEW &&tool_owner..trca$_non_recursive_v;
DROP VIEW &&tool_owner..trca$_non_recursive_vf;
DROP VIEW &&tool_owner..trca$_plan_table_vf;
DROP VIEW &&tool_owner..trca$_progress_v;
DROP VIEW &&tool_owner..trca$_purge_candidate_v;
DROP VIEW &&tool_owner..trca$_response_time_summary_v;
DROP VIEW &&tool_owner..trca$_response_time_summary_vf;
DROP VIEW &&tool_owner..trca$_row_source_plan_vf;
DROP VIEW &&tool_owner..trca$_row_source_plan_sess_vf;
DROP VIEW &&tool_owner..trca$_session_vf;
DROP VIEW &&tool_owner..trca$_sql_exec_time_v;
DROP VIEW &&tool_owner..trca$_sql_exec_time_vf;
DROP VIEW &&tool_owner..trca$_sql_exec_total_v;
DROP VIEW &&tool_owner..trca$_sql_exec_wait_v;
DROP VIEW &&tool_owner..trca$_sql_exec_wait_vf;
DROP VIEW &&tool_owner..trca$_sql_genealogy_v;
DROP VIEW &&tool_owner..trca$_sql_genealogy_vf;
DROP VIEW &&tool_owner..trca$_sql_recu_time_v;
DROP VIEW &&tool_owner..trca$_sql_recu_time_vf;
DROP VIEW &&tool_owner..trca$_sql_recu_total_v;
DROP VIEW &&tool_owner..trca$_sql_self_time_v;
DROP VIEW &&tool_owner..trca$_sql_self_time_vf;
DROP VIEW &&tool_owner..trca$_sql_self_total_v;
DROP VIEW &&tool_owner..trca$_sql_self_wait_v;
DROP VIEW &&tool_owner..trca$_sql_self_wait_vf;
DROP VIEW &&tool_owner..trca$_sql_v;
DROP VIEW &&tool_owner..trca$_sql_vf;
DROP VIEW &&tool_owner..trca$_sql_wait_seg_cons_v;
DROP VIEW &&tool_owner..trca$_sql_wait_seg_cons_vf;
DROP VIEW &&tool_owner..trca$_sql_wait_segment_v;
DROP VIEW &&tool_owner..trca$_sql_wait_segment_vf;
DROP VIEW &&tool_owner..trca$_trc_non_recu_time_v;
DROP VIEW &&tool_owner..trca$_trc_non_recu_time_vf;
DROP VIEW &&tool_owner..trca$_trc_non_recu_total_v;
DROP VIEW &&tool_owner..trca$_trc_non_recu_wait_v;
DROP VIEW &&tool_owner..trca$_trc_non_recu_wait_vf;
DROP VIEW &&tool_owner..trca$_trc_overall_time_v;
DROP VIEW &&tool_owner..trca$_trc_overall_time_vf;
DROP VIEW &&tool_owner..trca$_trc_overall_total_v;
DROP VIEW &&tool_owner..trca$_trc_overall_wait_v;
DROP VIEW &&tool_owner..trca$_trc_overall_wait_vf;
DROP VIEW &&tool_owner..trca$_trc_recu_time_v;
DROP VIEW &&tool_owner..trca$_trc_recu_time_vf;
DROP VIEW &&tool_owner..trca$_trc_recu_total_v;
DROP VIEW &&tool_owner..trca$_trc_recu_wait_v;
DROP VIEW &&tool_owner..trca$_trc_recu_wait_vf;
DROP VIEW &&tool_owner..trca$_trc_wait_segment_v;
DROP VIEW &&tool_owner..trca$_trc_wait_segment_vf;

-- package specs
DROP PACKAGE &&tool_owner..trca$g;
DROP PACKAGE &&tool_owner..trca$i;
DROP PACKAGE &&tool_owner..trca$e;
DROP PACKAGE &&tool_owner..trca$p;
DROP PACKAGE &&tool_owner..trca$r;
DROP PACKAGE &&tool_owner..trca$t;
DROP PACKAGE &&tool_owner..trca$x;

-- sequences
DROP SEQUENCE &&tool_owner..trca$_call_id_s;
DROP SEQUENCE &&tool_owner..trca$_cursor_id_s;
DROP SEQUENCE &&tool_owner..trca$_dep_id_s;
DROP SEQUENCE &&tool_owner..trca$_exec_id_s;
DROP SEQUENCE &&tool_owner..trca$_gap_id_s;
DROP SEQUENCE &&tool_owner..trca$_header_id_s;
DROP SEQUENCE &&tool_owner..trca$_session_id_s;
DROP SEQUENCE &&tool_owner..trca$_statement_id_s;
DROP SEQUENCE &&tool_owner..trca$_tool_execution_id_s;
DROP SEQUENCE &&tool_owner..trca$_trace_id_s;

-- tables
DROP TABLE &&tool_owner..trca$_file;
DROP TABLE &&tool_owner..trca$_files;
DROP TABLE &&tool_owner..trca$_audit_actions;
DROP TABLE &&tool_owner..trca$_bind;
DROP TABLE &&tool_owner..trca$_call;
DROP TABLE &&tool_owner..trca$_call_tree;
DROP TABLE &&tool_owner..trca$_cursor;
DROP TABLE &&tool_owner..trca$_data_type;
DROP TABLE &&tool_owner..trca$_error;
DROP TABLE &&tool_owner..trca$_event_name;
DROP TABLE &&tool_owner..trca$_exec;
DROP TABLE &&tool_owner..trca$_exec_binds;
DROP TABLE &&tool_owner..trca$_exec_tree;
DROP TABLE &&tool_owner..trca$_extents;
DROP TABLE &&tool_owner..trca$_file$;
DROP TABLE &&tool_owner..trca$_gap;
DROP TABLE &&tool_owner..trca$_gap_call;
DROP TABLE &&tool_owner..trca$_genealogy;
DROP TABLE &&tool_owner..trca$_genealogy_edge;
DROP TABLE &&tool_owner..trca$_group;
DROP TABLE &&tool_owner..trca$_group_call;
DROP TABLE &&tool_owner..trca$_group_exec_call;
DROP TABLE &&tool_owner..trca$_group_exec_wait;
DROP TABLE &&tool_owner..trca$_group_exec_wait_segment;
DROP TABLE &&tool_owner..trca$_group_indexes;
DROP TABLE &&tool_owner..trca$_group_row_source_plan;
DROP TABLE &&tool_owner..trca$_group_tables;
DROP TABLE &&tool_owner..trca$_group_wait;
DROP TABLE &&tool_owner..trca$_group_wait_segment;
DROP TABLE &&tool_owner..trca$_hot_block;
DROP TABLE &&tool_owner..trca$_hot_block_segment;
DROP TABLE &&tool_owner..trca$_ind_columns;
DROP TABLE &&tool_owner..trca$_indexes;
DROP TABLE &&tool_owner..trca$_objects;
DROP TABLE &&tool_owner..trca$_pivot;
DROP TABLE &&tool_owner..trca$_plan_table;
DROP TABLE &&tool_owner..trca$_row_source_plan;
DROP TABLE &&tool_owner..trca$_row_source_plan_session;
DROP TABLE &&tool_owner..trca$_segments;
DROP TABLE &&tool_owner..trca$_session;
DROP TABLE &&tool_owner..trca$_stat;
DROP TABLE &&tool_owner..trca$_stat_exec;
DROP TABLE &&tool_owner..trca$_statement;
DROP TABLE &&tool_owner..trca$_tab_cols;
DROP TABLE &&tool_owner..trca$_tables;
DROP TABLE &&tool_owner..trca$_tool_exec_call;
DROP TABLE &&tool_owner..trca$_tool_execution;
DROP TABLE &&tool_owner..trca$_tool_parameter;
DROP TABLE &&tool_owner..trca$_tool_wait;
DROP TABLE &&tool_owner..trca$_tool_wait_segment;
DROP TABLE &&tool_owner..trca$_trace;
DROP TABLE &&tool_owner..trca$_trace_header;
DROP TABLE &&tool_owner..trca$_wait;
DROP TABLE &&tool_owner..trca$_wait_event_name;
DROP TABLE &&tool_owner..trca$_file$;
DROP TABLE &&tool_owner..trca$_extents_dm;
DROP TABLE &&tool_owner..trca$_extents_lm;
DROP TABLE &&tool_owner..trca_control;
DROP TABLE &&tool_owner..trca_file;
DROP TABLE &&tool_owner..trca_segments;
DROP TABLE &&tool_owner..trca_extents_dm;
DROP TABLE &&tool_owner..trca_extents_lm;
DROP TABLE &&tool_owner..trca_tables;
DROP TABLE &&tool_owner..trca$_tables$;
DROP TABLE &&tool_owner..trca$_indexes$;
DROP TABLE &&tool_owner..trca_indexes;
DROP TABLE &&tool_owner..trca$_tab_cols$;
DROP TABLE &&tool_owner..trca_tab_cols;
DROP TABLE &&tool_owner..trca$_ind_columns$;
DROP TABLE &&tool_owner..trca_ind_columns;
DROP TABLE &&tool_owner..trca$_objects$;
DROP TABLE &&tool_owner..trca$_objects;
DROP TABLE &&tool_owner..trca$_parameter2$;
DROP TABLE &&tool_owner..trca_parameter2;
DROP TABLE &&tool_owner..trca$_users;
DROP TABLE &&tool_owner..trca_objects;

SET ECHO OFF TERM ON;
PRO TADOBJ completed.
