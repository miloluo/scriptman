REM $Header: sqcval0.sql 11.4.4.1 2012/01/02 carlos.sierra $
SET ECHO OFF VER OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET TERM ON;

REM Installation requires to connect as SYS
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'SQLT installation failed. Connect as SYS, not as '||USER);
  END IF;
END;
/

/*------------------------------------------------------------------*/

SET TERM OFF;

VAR rdbms_release NUMBER;
VAR rdbms_version VARCHAR2(17);
DECLARE
  dot1 NUMBER;
  dot2 NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'SELECT version FROM v$instance' INTO :rdbms_version;
  dot1 := INSTR(:rdbms_version, '.');
  dot2 := INSTR(:rdbms_version, '.', dot1 + 1);
  :rdbms_release :=
  TO_NUMBER(SUBSTR(:rdbms_version, 1, dot1 - 1)) +
  (TO_NUMBER(SUBSTR(:rdbms_version, dot1 + 1, dot2 - dot1 - 1)) / POWER(10, (dot2 - dot1 - 1)));
  IF :rdbms_release < 10 OR :rdbms_version < '10.2' THEN
    RAISE_APPLICATION_ERROR(-20200, 'SQLT installation failed. Install in 10.2 or higher, not in '||:rdbms_release);
  END IF;
END;
/
PRINT rdbms_release;
PRINT rdbms_version;

COL connect_identifier NEW_VALUE connect_identifier FOR A80;
COL prior_default_tablespace NEW_VALUE prior_default_tablespace FOR A30;
COL prior_temporary_tablespace NEW_VALUE prior_temporary_tablespace FOR A30;
COL tablespace_name FOR A30 HEA "TABLESPACE";
COL default_tablespace NEW_VALUE default_tablespace FOR A30;
COL temporary_tablespace NEW_VALUE temporary_tablespace FOR A30;
COL application_schema NEW_VALUE application_schema FOR A30;

SELECT 'UNKNOWN' prior_default_tablespace,
       'UNKNOWN' prior_temporary_tablespace
  FROM dual;

SELECT default_tablespace prior_default_tablespace,
       temporary_tablespace prior_temporary_tablespace
  FROM dba_users
 WHERE username = 'SQLTXPLAIN';

/*------------------------------------------------------------------*/
