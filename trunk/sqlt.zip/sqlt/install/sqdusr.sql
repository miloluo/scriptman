SET ECHO ON TERM OFF SERVEROUT ON SIZE 1000000;
REM
REM $Header: 215187.1 sqdusr.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqdusr.sql
REM
REM DESCRIPTION
REM   This script drops the SQLTXPLAIN user
REM
REM PRE-REQUISITES
REM   1. To drop SQLTXPLAIN user you must connect INTERNAL(SYS) as
REM      SYSDBA.
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory.
REM   2. Start SQL*Plus and connect INTERNAL(SYS) as SYSDBA.
REM   3. Execute script sqdusr.sql.
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqdusr.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqdrop.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop of SQLTXPLAIN failed. Connect as SYS, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET ECHO ON;

DECLARE
  my_count INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO my_count
    FROM dba_users
   WHERE username = 'TRCANLZR';
  IF my_count = 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'DROP PROCEDURE sqlt$_trca$_dir_set';
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Cannot drop procedure sqlt$_trca$_dir_set. '||SQLERRM);
    END;

    BEGIN
      EXECUTE IMMEDIATE 'DROP PROCEDURE tasqdirset';
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Cannot drop procedure tasqdirset. '||SQLERRM);
    END;

    FOR i IN (SELECT directory_name
                FROM dba_directories
               WHERE directory_name IN ('SQLT$UDUMP', 'SQLT$BDUMP', 'SQLT$STAGE', 'TRCA$INPUT1', 'TRCA$INPUT2', 'TRCA$STAGE'))
    LOOP
      BEGIN
        EXECUTE IMMEDIATE 'DROP DIRECTORY '||i.directory_name;
        DBMS_OUTPUT.PUT_LINE('Dropped directory '||i.directory_name||'.');
      EXCEPTION
        WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('Cannot drop directory '||i.directory_name||'. '||SQLERRM);
      END;
    END LOOP;
  END IF;
END;
/

DROP ROLE sqlt_user_role;

DROP USER sqltxplain CASCADE;

SET ECHO OFF;
PRO
PRO SQDUSR completed.
