SET ECHO ON TERM OFF;
SPO 08_sqcpkg.log;
REM
REM $Header: 215187.1 sqcpkg.sql 11.4.4.7 2012/07/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqcpkg.sql
REM
REM DESCRIPTION
REM   Creates all SQLT packages owned by user SQLTXPLAIN
REM   SQLT$I Invoker rights APIs (AUTHID CURRENT_USER)
REM   SQLT$D Diagnostics data collection
REM   SQLT$A Auxiliary APIs
REM   SQLT$S CBO Statistics APIs
REM   SQLT$T Transformation of diagnostics data
REM   SQLT$H Health-Checks
REM   SQLT$M Main report
REM   SQLT$R Reports and APIs for reporting
REM   SQLT$C Compare report
REM   SQLT$E External APIs
REM
REM PRE-REQUISITES
REM   1. Connect as SQLTXPLAIN.
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus and connect as SQLTXPLAIN
REM   3. Execute this script sqcpkg.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus sqltxplan
REM   SQL> START sqcpkg.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqcreate.sql
REM   2. For possible errors see sqcpkg.log file
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common

ALTER SESSION SET PLSQL_CODE_TYPE = INTERPRETED;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET ECHO OFF TERM ON;

BEGIN
  IF USER <> 'SQLTXPLAIN' THEN
    RAISE_APPLICATION_ERROR(-20100, 'SQLT packages creation failed. Connect as SQLTXPLAIN, not as '||USER);
  END IF;
END;
/

-- set rdbms_version
VAR rdbms_release NUMBER;
VAR rdbms_version VARCHAR2(17);
DECLARE
  dot1 NUMBER;
  dot2 NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'SELECT version FROM v$instance' INTO :rdbms_version;
  dot1 := INSTR(:rdbms_version, '.');
  dot2 := INSTR(:rdbms_version, '.', dot1 + 1);
  :rdbms_release :=
  TO_NUMBER(SUBSTR(:rdbms_version, 1, dot1 - 1)) +
  (TO_NUMBER(SUBSTR(:rdbms_version, dot1 + 1, dot2 - dot1 - 1)) / POWER(10, (dot2 - dot1 - 1)));
  IF :rdbms_release < 10 OR :rdbms_version < '10.2' THEN
    RAISE_APPLICATION_ERROR(-20200, 'SQLT installation failed. Install in 10.2 or higher, not in '||:rdbms_release);
  END IF;
END;
/
PRINT rdbms_release;
PRINT rdbms_version;
--
--
-- need to set "skip_if_prior_to_112" so we can comment out code lines that would fail on releases prior to 11.2
-- this variable gets a value of NULL if executed on 11.2 or higher, but it becomes a comment if executed on pre 11.2
COL skip_if_prior_to_112 NEW_V skip_if_prior_to_112;
SELECT '-- skip_if_prior_to_112: ' skip_if_prior_to_112 FROM DUAL WHERE :rdbms_version < '11.2';
--
--
SET TERM ON;
PRO ... creating package specs for SQLT$A
SET TERM OFF;
@@sqcpkga.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$C
SET TERM OFF;
@@sqcpkgc.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$D
SET TERM OFF;
@@sqcpkgd.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$E
SET TERM OFF;
@@sqcpkge.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$H
SET TERM OFF;
@@sqcpkgh.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$I
SET TERM OFF;
@@sqcpkgi.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$M
SET TERM OFF;
@@sqcpkgm.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$R
SET TERM OFF;
@@sqcpkgr.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$S
SET TERM OFF;
@@sqcpkgs.pks
--
SET TERM ON;
PRO ... creating package specs for SQLT$T
SET TERM OFF;
@@sqcpkgt.pks
--
SET TERM ON;
PRO ... creating views
SET TERM OFF;
@@sqcvw.sql
--
SET TERM ON;
PRO ... creating procedures
SET TERM OFF;
@@sqcmigrate.sql
--
SET TERM ON;
PRO ... creating package body for SQLT$A
SET TERM OFF;
@@sqcpkga.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$C
SET TERM OFF;
@@sqcpkgc.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$D
SET TERM OFF;
@@sqcpkgd.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$E
SET TERM OFF;
@@sqcpkge.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$H
SET TERM OFF;
@@sqcpkgh.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$I
SET TERM OFF;
@@sqcpkgi.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$M
SET TERM OFF;
@@sqcpkgm.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$R
SET TERM OFF;
@@sqcpkgr.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$S
SET TERM OFF;
@@sqcpkgs.pkb
--
SET TERM ON;
PRO ... creating package body for SQLT$T
SET TERM OFF;
@@sqcpkgt.pkb
--
SET TERM ON;
PRO
PRO Creating Grants on Packages ...
PRO
SET TERM OFF;
--
GRANT EXECUTE ON sqlt$migrate TO &&role_name.;
GRANT EXECUTE ON sqlt$a TO &&role_name.;
GRANT EXECUTE ON sqlt$c TO &&role_name.;
GRANT EXECUTE ON sqlt$d TO &&role_name.;
GRANT EXECUTE ON sqlt$e TO &&role_name.;
GRANT EXECUTE ON sqlt$h TO &&role_name.;
GRANT EXECUTE ON sqlt$i TO &&role_name.;
GRANT EXECUTE ON sqlt$m TO &&role_name.;
GRANT EXECUTE ON sqlt$r TO &&role_name.;
GRANT EXECUTE ON sqlt$s TO &&role_name.;
GRANT EXECUTE ON sqlt$t TO &&role_name.;
--
SET ECHO OFF PAGES 24;
DEF _SQLPLUS_RELEASE
SELECT * FROM v$version;
COL libraries FOR A64;
SET TERM ON FEED OFF;
SELECT column_value libraries FROM TABLE(sqlt$r.libraries_versions);
DECLARE
  my_count INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO my_count
    FROM sys.user_objects
   WHERE object_type IN ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'FUNCTION')
     AND status = 'INVALID';
  IF my_count > 0 THEN
    RAISE_APPLICATION_ERROR(-20110, 'Invalid libraries: '||my_count||'. Review sqcpkg.log.');
  END IF;
END;
/
SET FEED 6;
--
PRO
PRO  Migrating relevant objects from old to new repository ...
PRO
EXEC sqlt$migrate;
--
PRO
PRO  Deleting CBO statistics for SQLTXPLAIN objects ...
PRO
EXEC sqlt$a.delete_sqltxplain_stats;
--
WHENEVER SQLERROR CONTINUE;
PRO
PRO SQCPKG completed.
SPO OFF;
