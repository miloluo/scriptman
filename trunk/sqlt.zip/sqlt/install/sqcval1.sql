REM $Header: sqcval1.sql 11.4.5.0 2012/11/21 carlos.sierra $

SET ECHO OFF VER OFF TERM OFF;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SELECT CASE WHEN UPPER(TRIM(NVL('&&connect_identifier.', 'NULL'))) = 'NULL' THEN NULL ELSE TRIM('&&connect_identifier.') END connect_identifier FROM DUAL;
SET TERM ON;

REM Connect identifier must be null, "NULL" or "@PROD" where PROD is a valid alias
BEGIN
  IF '&&connect_identifier.' IS NOT NULL AND '&&connect_identifier.' NOT LIKE '@%' THEN
    RAISE_APPLICATION_ERROR(-20103, 'Install failed - Incorrect Connect Identifier, it must start with "@": &&connect_identifier.');
  END IF;
END;
/

/*------------------------------------------------------------------*/
