CREATE OR REPLACE PROCEDURE sqlt$migrate AS
/* $Header: 215187.1 sqcmigrate.sql 11.4.4.3 2012/03/02 carlos.sierra $ */
  l_source VARCHAR2(30);
BEGIN
  -- purge target repository first
  DELETE sqlt$_sql_statement WHERE statement_id IN (SELECT statement_id FROM sqlt$_statement);
  DELETE sqlt$_plan_extension WHERE statement_id IN (SELECT TO_CHAR(statement_id) statement_id FROM sqlt$_statement);
  DELETE sqlt$_gv$parameter_cbo WHERE statement_id IN (SELECT TO_NUMBER(SUBSTR(statid, 2, INSTR(statid, CHR(95)) - 2)) statement_id FROM sqlt$_parameter2);
  DELETE sqlt$_v$session_fix_control WHERE statement_id IN (SELECT TO_NUMBER(SUBSTR(statid, 2, INSTR(statid, CHR(95)) - 2)) statement_id FROM sqlt$_parameter2);
  DELETE sqlt$_gv$parameter2 WHERE statement_id IN (SELECT TO_NUMBER(SUBSTR(statid, 2, INSTR(statid, CHR(95)) - 2)) statement_id FROM sqlt$_parameter2);
  DELETE sqlt$_dba_indexes WHERE statement_id IN (SELECT statement_id FROM sqlt$_indexes);
  DELETE sqlt$_dba_ind_columns WHERE statement_id IN (SELECT statement_id FROM sqlt$_ind_columns);
  DELETE sqlt$_dba_tab_cols WHERE statement_id IN (SELECT statement_id FROM sqlt$_tab_columns);

  -- sqlt$_statement => sqlt$_sql_statement
  FOR i IN (SELECT * FROM sqlt$_statement)
  LOOP
    INSERT INTO sqlt$_sql_statement (
      statement_id,
      statid,
      method,
      input_filename,
      host_name_short,
      cpu_count,
      rac,
      database_id,
      database_name_short,
      instance_number,
      instance_name_short,
      platform,
      product_version,
      rdbms_version,
      rdbms_version_short,
      rdbms_release,
      language,
      apps_release,
      apps_system_name,
      hash_value,
      sql_id,
      signature_so,
      signature_sta,
      command_type,
      sql_length,
      sql_text,
      sql_text_clob,
      sql_text_clob_stripped,
      user_id,
      username,
      tool_start_date,
      tool_end_date,
      param_autostats_target,
      param_publish,
      param_incremental,
      param_stale_percent,
      param_estimate_percent,
      param_degree,
      param_cascade,
      param_no_invalidate,
      param_method_opt,
      param_granularity,
      optimizer_features_enable,
      db_block_size,
      cpuspeednw,
      cpuspeed,
      ioseektim,
      iotfrspeed,
      mbrc,
      sreadtim,
      mreadtim,
      maxthr,
      slavethr,
      cpu_cost_scaling_factor,
      synthetized_mbrc_and_readtim,
      worst_plan_hash_value
    ) VALUES (
      i.statement_id,
      i.statid,
      i.method,
      i.input_filename,
      i.host_name_short,
      i.cpu_count,
      i.rac,
      i.database_id,
      i.database_name_short,
      i.instance_number,
      i.instance_name_short,
      i.platform,
      i.product_version,
      i.rdbms_version,
      i.rdbms_version_short,
      i.rdbms_release,
      i.language,
      i.apps_release,
      i.apps_system_name,
      i.hash_value,
      i.sql_id,
      i.signature,
      i.signaturen,
      i.command_type,
      i.sql_length,
      REPLACE(REPLACE(REPLACE(i.sql_text, CHR(13)), CHR(10), ' '), CHR(9), ' '), -- flat
      i.sql_text_clob,
      i.sql_text_clob_stripped,
      i.user_id,
      i.username,
      i.tool_start_date,
      i.tool_end_date,
      i.param_autostats_target,
      i.param_publish,
      i.param_incremental,
      i.param_stale_percent,
      i.param_estimate_percent,
      i.param_degree,
      i.param_cascade,
      i.param_no_invalidate,
      i.param_method_opt,
      i.param_granularity,
      i.optimizer_features_enable,
      i.db_block_size,
      i.cpuspeednw,
      i.cpuspeed,
      i.ioseektim,
      i.iotfrspeed,
      i.mbrc,
      i.sreadtim,
      i.mreadtim,
      i.maxthr,
      i.slavethr,
      i.cpu_cost_scaling_factor,
      'Y',
      i.worst_plan_hash_value
    );
  END LOOP;

  -- sqlt$_plan_table and sqlt$_statement => sqlt$_plan_extension
  FOR i IN (SELECT p.*,
                   CASE
                   WHEN s.plan_source = 'V$SQL_PLAN' THEN 'GV$SQL_PLAN'
                   WHEN s.plan_source = 'GV$SQL_PLAN' THEN 'GV$SQL_PLAN'
                   WHEN s.plan_source = 'DBA_HIST_SQL_PLAN' THEN 'DBA_HIST_SQL_PLAN'
                   WHEN s.plan_source = 'EXPLAIN PLAN FOR' THEN 'PLAN_TABLE'
                   ELSE 'UNKNOWN' END source,
                   s.inst_id,
                   s.address,
                   s.hash_value,
                   s.sql_id,
                   s.plan_hash_value,
                   s.child_number
              FROM sqlt$_plan_table p,
                   sqlt$_statement s
             WHERE p.statement_id = TO_CHAR(s.statement_id))
  LOOP
    INSERT INTO sqlt$_plan_extension (
      statement_id,
      statid,
      source,
      inst_id,
      address,
      hash_value,
      sql_id,
      plan_hash_value,
      plan_id,
      task_id,
      child_number,
      timestamp,
      operation,
      options,
      object_node,
      object#,
      object_owner,
      object_name,
      object_alias,
      object_type,
      optimizer,
      id,
      parent_id,
      depth,
      position,
      search_columns,
      cost,
      cardinality,
      bytes,
      other_tag,
      partition_start,
      partition_stop,
      partition_id,
      other,
      distribution,
      cpu_cost,
      io_cost,
      temp_space,
      access_predicates,
      filter_predicates,
      projection,
      time,
      qblock_name,
      remarks,
      other_xml,
      real_depth,
      exec_order
    ) VALUES (
      TO_NUMBER(i.statement_id),
      i.statid,
      i.source,
      i.inst_id,
      i.address,
      i.hash_value,
      i.sql_id,
      i.plan_hash_value,
      NVL(i.plan_id, -1),
      -1,
      NVL(i.child_number, -1),
      i.timestamp,
      i.operation,
      i.options,
      i.object_node,
      i.object#,
      i.object_owner,
      i.object_name,
      i.object_alias,
      i.object_type,
      i.optimizer,
      i.id,
      i.parent_id,
      i.depth,
      i.position,
      i.search_columns,
      i.cost,
      i.cardinality,
      i.bytes,
      i.other_tag,
      i.partition_start,
      i.partition_stop,
      i.partition_id,
      i.other,
      i.distribution,
      i.cpu_cost,
      i.io_cost,
      i.temp_space,
      i.access_predicates,
      i.filter_predicates,
      i.projection,
      i.time,
      i.qblock_name,
      i.remarks,
      i.other_xml,
      i.indent,
      i.execution_order
    );
  END LOOP;

  -- sqlt$_parameter2 => sqlt$_gv$parameter_cbo, sqlt$_v$session_fix_control and sqlt$_gv$parameter2
  FOR i IN (SELECT * FROM sqlt$_parameter2)
  LOOP
    --DBMS_OUTPUT.PUT_LINE(i.source||' '||i.name||' '||i.value);
    IF i.source IN ('PAR_USED_CBO', 'PAR_ALTER_VALUE', 'PAR_DEF_VALUE') THEN
      INSERT INTO sqlt$_gv$parameter_cbo (
        statement_id,
        statid,
        inst_id,
        num,
        name,
        value,
        display_value,
        isdefault,
        description
      ) VALUES (
        TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2)),
        i.statid,
        i.inst_id,
        i.num,
        i.name,
        i.value,
        i.display_value,
        i.is_default,
        i.description
      );
    ELSIF i.source = 'BUG_FIX_CTRL' THEN
      INSERT INTO sqlt$_v$session_fix_control (
        statement_id,
        statid,
        bugno,
        value,
        description,
        optimizer_feature_enable,
        is_default
      ) VALUES (
        TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2)),
        i.statid,
        TO_NUMBER(i.name),
        DECODE(TRIM(' ' FROM REPLACE(i.value, '*')), 'enabled', 1, 'disabled', 0, TO_NUMBER(TRIM(' ' FROM REPLACE(i.value, '*')))),
        i.description,
        i.optimizer_feature_enable,
        DECODE(i.is_default, 'N', 0, 'Y', 1, TO_NUMBER(NULL))
      );
    ELSIF i.source = 'GV$PARAMETER2' THEN
      INSERT INTO sqlt$_gv$parameter2 (
        statement_id,
        statid,
        inst_id,
        num,
        name,
        type,
        value,
        display_value,
        isdefault,
        isses_modifiable,
        issys_modifiable,
        isinstance_modifiable,
        ismodified,
        isadjusted,
        isdeprecated,
        description,
        ordinal
      ) VALUES (
        TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2)),
        i.statid,
        i.inst_id,
        i.num,
        i.name,
        i.type,
        i.value,
        i.display_value,
        i.is_default,
        i.is_session_modifiable,
        i.is_system_modifiable,
        i.is_instance_modifiable,
        i.is_modified,
        i.is_adjusted,
        i.is_deprecated,
        i.description,
        i.ordinal
      );

      IF i.name = 'db_file_multiblock_read_count' THEN
        UPDATE sqlt$_sql_statement
           SET db_file_multiblock_read_count = i.value
         WHERE statement_id = TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2));
      END IF;

      IF i.name = '_db_file_optimizer_read_count' THEN
        UPDATE sqlt$_sql_statement
           SET udb_file_optimizer_read_count = i.value
         WHERE statement_id = TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2));
      END IF;
    END IF;
  END LOOP;

  -- sqlt$_indexes => sqlt$_dba_indexes
  FOR i IN (SELECT * FROM sqlt$_indexes)
  LOOP
    INSERT INTO sqlt$_dba_indexes (
      statement_id,
      statid,
      owner,
      index_name,
      index_type,
      table_owner,
      table_name,
      uniqueness,
      tablespace_name,
      ini_trans,
      max_trans,
      freelists,
      freelist_groups,
      logging,
      blevel,
      leaf_blocks,
      distinct_keys,
      avg_leaf_blocks_per_key,
      avg_data_blocks_per_key,
      clustering_factor,
      status,
      num_rows,
      sample_size,
      last_analyzed,
      degree,
      partitioned,
      temporary,
      user_stats,
      ityp_owner,
      ityp_name,
      global_stats,
      domidx_status,
      funcidx_status,
      object_id,
      in_plan
    ) VALUES (
      i.statement_id,
      i.statid,
      i.owner,
      i.index_name,
      i.index_type,
      i.table_owner,
      i.table_name,
      i.uniqueness,
      i.tablespace_name,
      i.ini_trans,
      i.max_trans,
      i.freelists,
      i.freelist_groups,
      i.logging,
      i.blevel,
      i.leaf_blocks,
      i.distinct_keys,
      i.avg_leaf_blocks_per_key,
      i.avg_data_blocks_per_key,
      i.clustering_factor,
      i.status,
      i.num_rows,
      i.sample_size,
      i.last_analyzed,
      i.degree,
      i.partitioned,
      i.temporary,
      i.user_stats,
      i.ityp_owner,
      i.ityp_name,
      i.global_stats,
      i.domidx_status,
      i.funcidx_status,
      i.object_id,
      DECODE(i.in_operations, NULL, 'FALSE', 'TRUE')
    );
  END LOOP;

  -- sqlt$_ind_columns => sqlt$_dba_ind_columns
  FOR i IN (SELECT * FROM sqlt$_ind_columns)
  LOOP
    INSERT INTO sqlt$_dba_ind_columns (
      statement_id,
      statid,
      index_owner,
      index_name,
      table_owner,
      table_name,
      column_name,
      column_position,
      column_length,
      char_length,
      descend
    ) VALUES (
      i.statement_id,
      i.statid,
      i.index_owner,
      i.index_name,
      i.table_owner,
      i.table_name,
      i.column_name,
      i.column_position,
      i.column_length,
      i.char_length,
      i.descend
    );
  END LOOP;

  -- sqlt$_tab_columns => sqlt$_dba_tab_cols
  FOR i IN (SELECT * FROM sqlt$_tab_columns)
  LOOP
    INSERT INTO sqlt$_dba_tab_cols (
      statement_id,
      statid,
      owner,
      table_name,
      column_name,
      data_type,
      data_type_mod,
      data_type_owner,
      data_length,
      data_precision,
      data_scale,
      nullable,
      column_id,
      data_default,
      num_distinct,
      low_value,
      high_value,
      density,
      num_nulls,
      num_buckets,
      last_analyzed,
      sample_size,
      character_set_name,
      global_stats,
      user_stats,
      avg_col_len,
      char_length,
      char_used,
      hidden_column,
      histogram,
      qualified_col_name,
      low_value_cooked,
      high_value_cooked,
      popular_values,
      buckets_pop_vals,
      new_density,
      mutating_endpoints,
      in_predicates,
      in_indexes
    ) VALUES (
      i.statement_id,
      i.statid,
      i.owner,
      i.table_name,
      i.column_name,
      i.data_type,
      i.data_type_mod,
      i.data_type_owner,
      i.data_length,
      i.data_precision,
      i.data_scale,
      i.nullable,
      i.column_id,
      i.data_default,
      i.num_distinct,
      i.low_value,
      i.high_value,
      i.density,
      i.num_nulls,
      i.num_buckets,
      i.last_analyzed,
      i.sample_size,
      i.character_set_name,
      i.global_stats,
      i.user_stats,
      i.avg_col_len,
      i.char_length,
      i.char_used,
      i.hidden_column,
      i.histogram,
      i.qualified_col_name,
      i.low_value_boiled,
      i.high_value_boiled,
      i.popular_value_count,
      i.buckets_popular_value,
      i.new_density,
      DECODE(i.mutating_num_buckets, 'YES', 'TRUE', 'FALSE'),
      DECODE(i.in_predicates, 'Y', 'TRUE', 'FALSE'),
      DECODE(i.index_count, NULL, 'FALSE', 0, 'FALSE', 'TRUE')
    );
  END LOOP;

  -- transformations
  FOR i IN (SELECT DISTINCT statement_id, plan_source FROM sqlt$_statement)
  LOOP
    -- sqlt$_plan_extension
    sqlt$t.top_cost(i.statement_id);
    sqlt$t.plan_operation(i.statement_id);
    sqlt$t.build_plan_more_html_table(i.statement_id);
    sqlt$t.sanitize_other_xml(i.statement_id);

    -- other xml
    BEGIN
      sqlt$t.process_other_xml(i.statement_id);
      IF i.plan_source = 'V$SQL_PLAN' THEN
        l_source := 'GV$SQL_PLAN';
      ELSIF i.plan_source = 'GV$SQL_PLAN' THEN
        l_source := 'GV$SQL_PLAN';
      ELSIF i.plan_source = 'DBA_HIST_SQL_PLAN' THEN
        l_source := 'DBA_HIST_SQL_PLAN';
      ELSIF i.plan_source = 'EXPLAIN PLAN FOR' THEN
        l_source := 'PLAN_TABLE';
      ELSE
        l_source := 'UNKNOWN';
      END IF;
      UPDATE sqlt$_peeked_binds SET source = l_source WHERE statement_id = i.statement_id;
      UPDATE sqlt$_plan_info SET source = l_source WHERE statement_id = i.statement_id;
      UPDATE sqlt$_outline_data SET source = l_source WHERE statement_id = i.statement_id;
    END;

    -- more sqlt$_plan_extension
    sqlt$t.extend_peeked_binds(i.statement_id); -- depends on process_other_xml
    sqlt$t.binds_in_predicates(i.statement_id); -- depends on extend_peeked_binds

    -- sqlt$_dba_tab_cols
    sqlt$t.column_in_predicates(i.statement_id);
    sqlt$t.column_in_projection(i.statement_id); -- depends on column_in_predicates
  END LOOP;

  -- only sqlt$_stattab was imported
  FOR i IN (SELECT statid
              FROM sqlt$_stattab
             WHERE statid LIKE 's%'
               AND type = 'T'
               AND c2 IS NULL
               AND statid NOT LIKE '%^_BK^_20%' ESCAPE '^' -- "%_BK_20%"
             MINUS
            SELECT statid
              FROM sqlt$_sql_statement)
  LOOP
    INSERT INTO sqlt$_sql_statement (
      statement_id,
      statid,
      sql_text
    ) VALUES (
      TO_NUMBER(SUBSTR(i.statid, 2, INSTR(i.statid, CHR(95)) - 2)),
      i.statid,
      'SQLT$_STATTAB'
    );
  END LOOP;

  -- purge source repository
  DELETE sqlt$_tab_columns;
  DELETE sqlt$_ind_columns;
  DELETE sqlt$_indexes;
  DELETE sqlt$_parameter2;
  DELETE sqlt$_plan_table;
  DELETE sqlt$_statement;

  -- keep xplain_sql_id only if different than sql_id
  UPDATE sqlt$_sql_statement
     SET xplain_sql_id = NULL
   WHERE xplain_sql_id = sql_id;

  -- one commit only
  COMMIT;
END sqlt$migrate;
/

-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common

SET TERM ON;
SHOW ERRORS;
