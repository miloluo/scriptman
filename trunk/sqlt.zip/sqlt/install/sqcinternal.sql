REM $Header: sqcinternal.sql 11.4.3.5 2011/08/10 carlos.sierra $
@@sqdefparams.sql
@@sqcsilent.sql
