SET ECHO ON TERM OFF VER OFF NUMF "";
SPOOL 02_tacusr.log;
REM
REM $Header: 224270.1 tacusr.sql 11.4.4.1 2012/01/02 trcanlzr $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   tacusr.sql
REM
REM DESCRIPTION
REM   This script creates user TRCANLZR and the grants it needs
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM   2. The following 2 utilities must be pre-installed:
REM        o  sys.dbms_random
REM        o  sys.utl_file
REM   3. During the installation you will be asked to enter the
REM      follwing:
REM        o  Connect Identifier - Optional
REM           Some restricted-access systems may need to specify
REM           a connect identifier like "@PROD".
REM           This optional parameter allows to enter it. Else,
REM           enter nothing and just hit the "Enter" key.
REM        o  TRCANLZR password - Required and it has no default
REM        o  TRCANLZR default tablespace - You will be presented
REM           with a list, then you will have to enter one tablespace
REM           name from that list
REM        o  TRCANLZR temporary tablespace - Similar as above
REM        o  Type of object for large staging tables - Enter "T" is
REM           you want large tables to be created as PERMANENT, or
REM           "N" if you prefer GLOBAL TEMPORARY (recommended)
REM
REM PARAMETERS
REM   1. None inline. During the installation you will be asked for
REM      the values of the parameters described under pre-requisites
REM      section above
REM
REM EXECUTION
REM   1. Navigate to trca/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA
REM   3. Execute script tacusr.sql
REM
REM EXAMPLE
REM   # cd trca/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start tacusr.sql
REM
REM NOTES
REM   1. This script is executed automatically by tacreate.sql
REM   2. For possible errors see tacusr.log file
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ".,";
DECLARE
  rdbms_release NUMBER;
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Install failed - TRCANLZR should be installed connected as SYS, not as '||USER);
  END IF;
  SELECT TO_NUMBER(SUBSTR(version, 1, INSTR(version, '.', 1, 2) - 1))
    INTO rdbms_release
    FROM v$instance;
  IF rdbms_release < 9.2 THEN
    RAISE_APPLICATION_ERROR(-20200, 'Install failed - TRCANLZR should be installed in 9i(9.2) or higher, not in '||rdbms_release);
  END IF;
END;
/

/* ---------------------------------------------------------------------- */

PRO
PRO Specify optional Connect Identifier (as per Oracle Net)
PRO Include "@" symbol, ie. @PROD
PRO If not applicable, enter nothing and hit the "Enter" key
PRO
ACC connect_identifier PROMPT 'Optional Connect Identifier (ie: @PROD): ';
PRO

BEGIN
  IF '&&connect_identifier.' IS NOT NULL AND '&&connect_identifier.' NOT LIKE '@%' THEN
    RAISE_APPLICATION_ERROR(-20103, 'Install failed - Incorrect Connect Identifier, it must start with "@": &&connect_identifier.');
  END IF;
END;
/

/* ---------------------------------------------------------------------- */

PRO
PRO Define the TRCANLZR user password (hidden and case sensitive).
PRO
ACC trcanlzr_password PROMPT 'Specify TRCANLZR password: ' HIDE;
ACC trcanlzr_password2 PROMPT 'Re-enter password: ' HIDE;
PRO

BEGIN
  IF '&&trcanlzr_password.' IS NULL THEN
    RAISE_APPLICATION_ERROR(-20102, 'Install failed - No password specified for TRCANLZR user');
  END IF;
  IF NVL('&&trcanlzr_password.', '-666') LIKE '% %' THEN
    RAISE_APPLICATION_ERROR(-20102, 'Install failed - Password for TRCANLZR user cannot contain spaces');
  END IF;
  IF NVL('&&trcanlzr_password.', '-666') <> NVL('&&trcanlzr_password2.', '-999') THEN
    RAISE_APPLICATION_ERROR(-20106, 'Re-entered password did not match');
  END IF;
END;
/

CREATE USER trcanlzr IDENTIFIED BY "&&trcanlzr_password.";

/* ---------------------------------------------------------------------- */


SET ECHO ON TERM OFF;
PRO
PRO  Create TRCANLZR grant privileges
PRO

PRO
PRO System privileges
PRO
GRANT ALTER  SESSION        TO trcanlzr;
GRANT CREATE PROCEDURE      TO trcanlzr;
GRANT CREATE SEQUENCE       TO trcanlzr;
GRANT CREATE SESSION        TO trcanlzr;
GRANT CREATE TABLE          TO trcanlzr;
GRANT CREATE VIEW           TO trcanlzr;
GRANT SELECT ANY DICTIONARY TO trcanlzr;

PRO
PRO Roles privileges
PRO
GRANT SELECT_CATALOG_ROLE TO trcanlzr;

PRO
PRO Utilities privileges
PRO
DECLARE
  PROCEDURE grant_execute (
    p_owner   IN VARCHAR2,
    p_package IN VARCHAR2 )
  IS
    my_count INTEGER;
  BEGIN
    SELECT COUNT(*)
      INTO my_count
      FROM dba_tab_privs
     WHERE owner      = UPPER(p_owner)
       AND table_name = UPPER(p_package)
       AND privilege  = 'EXECUTE'
       AND grantee   IN ('PUBLIC', 'TRCANLZR');
     IF my_count = 0 THEN
       EXECUTE IMMEDIATE 'GRANT EXECUTE ON '||p_owner||'.'||p_package||' TO trcanlzr';
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SUCCEEDED.');
     ELSE
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SKIPPED.');
     END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' FAILED: '||SQLERRM);
  END grant_execute;
BEGIN
  grant_execute('sys', 'dbms_lob');
  grant_execute('sys', 'dbms_random');
  grant_execute('sys', 'dbms_space_admin');
  grant_execute('sys', 'dbms_stats');
  grant_execute('sys', 'utl_file');
END;
/

PRO
PRO X$ tables
PRO
CREATE OR REPLACE VIEW sys.x_$ktfbue AS SELECT * FROM sys.x$ktfbue;
GRANT SELECT ON sys.x_$ktfbue TO trcanlzr;
DECLARE
  my_count INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO my_count
    FROM dba_users
   WHERE username = 'SQLTXPLAIN';
  IF my_count > 0 THEN
    EXECUTE IMMEDIATE 'GRANT SELECT ON sys.x_$ktfbue TO sqltxplain';
  END IF;
END;
/

/* ---------------------------------------------------------------------- */

SET ECHO OFF TERM ON;
PRO
PRO Set up TRCANLZR temporary and default tablespaces;
PRO
PRO Below are the list of online tablespaces in this database.
PRO Decide which tablespace you wish to create the TRCANLZR tables
PRO and indexes.  This will also be the TRCANLZR user default tablespace.
PRO
PRO Specifying the SYSTEM tablespace will result in the installation
PRO FAILING, as using SYSTEM for tools data is not supported.
PRO
PRO Wait...
PRO

COL tablespace_name FOR A30;
SELECT t.tablespace_name,
       f.free_space_mb
  FROM sys.dba_tablespaces t,
       (SELECT tablespace_name,
               NVL(ROUND(SUM(bytes)/1024/1024), 0) free_space_mb
          FROM sys.dba_free_space
         GROUP BY
               tablespace_name) f
 WHERE t.tablespace_name NOT IN ('SYSTEM', 'SYSAUX')
   AND t.status = 'ONLINE'
   AND t.contents = 'PERMANENT'
   AND t.tablespace_name = f.tablespace_name
   AND f.free_space_mb > 50
 ORDER BY f.free_space_mb;

PRO
PRO Above is the list of online tablespaces in this database.
PRO Decide which tablespace you wish to create the TRCANLZR tables
PRO and indexes.  This will also be the TRCANLZR user default tablespace.
PRO
PRO Specifying the SYSTEM tablespace will result in the installation
PRO FAILING, as using SYSTEM for tools data is not supported.
PRO
PRO Tablespace name is case sensitive.
PRO

COL default_tablespace NEW_VALUE default_tablespace FOR A30;
PRO
ACC default_tablespace PROMPT 'Default tablespace [&&prior_default_tablespace.]: ';
SELECT TRIM(NVL('&&default_tablespace.', '&&prior_default_tablespace.')) default_tablespace FROM DUAL;

BEGIN
  IF UPPER('&&default_tablespace.') IN ('SYSTEM', 'SYSAUX') THEN
    RAISE_APPLICATION_ERROR(-20104, 'Install failed - SYSTEM/SYSAUX tablespace specified for DEFAULT tablespace');
  END IF;
END;
/

SET ECHO ON TERM OFF;
ALTER USER trcanlzr DEFAULT TABLESPACE "&&default_tablespace.";
ALTER USER trcanlzr QUOTA UNLIMITED ON "&&default_tablespace.";
SET ECHO OFF TERM ON;

PRO
PRO Choose the TRCANLZR user temporary tablespace.
PRO
PRO Specifying the SYSTEM tablespace will result in the installation
PRO FAILING, as using SYSTEM for the temporary tablespace is not recommended.
PRO
PRO Wait...
PRO

SET SERVEROUT ON SIZE 1000000
DECLARE
  TYPE cursor_type IS REF CURSOR;
  c_temp_table_spaces cursor_type;
  rdbms_release NUMBER;
  my_tablespace VARCHAR2(32767);
  my_sql VARCHAR2(32767);
BEGIN
  SELECT TO_NUMBER(SUBSTR(version, 1, INSTR(version, '.', 1, 2) - 1))
    INTO rdbms_release
    FROM v$instance;

  IF rdbms_release < 10 THEN
    my_sql := 'SELECT tablespace_name '||
              '  FROM sys.dba_tablespaces '||
              ' WHERE tablespace_name NOT IN (''SYSTEM'', ''SYSAUX'') '||
              '   AND status = ''ONLINE'' '||
              '   AND contents = ''TEMPORARY'' '||
              ' ORDER BY tablespace_name ';
  ELSE
    my_sql := 'SELECT t.tablespace_name '||
              '  FROM sys.dba_tablespaces t '||
              ' WHERE t.tablespace_name NOT IN (''SYSTEM'', ''SYSAUX'') '||
              '   AND t.status = ''ONLINE'' '||
              '   AND t.contents = ''TEMPORARY'' '||
              '   AND NOT EXISTS ( '||
              'SELECT NULL '||
              '  FROM sys.dba_tablespace_groups tg '||
              ' WHERE t.tablespace_name = tg.tablespace_name ) '||
              ' UNION '||
              'SELECT tg.group_name '||
              '  FROM sys.dba_tablespaces t, '||
              '       sys.dba_tablespace_groups tg '||
              ' WHERE t.tablespace_name NOT IN (''SYSTEM'', ''SYSAUX'') '||
              '   AND t.status = ''ONLINE'' '||
              '   AND t.contents = ''TEMPORARY'' '||
              '   AND t.tablespace_name = tg.tablespace_name ';
  END IF;

  DBMS_OUTPUT.PUT_LINE('TABLESPACE_NAME');
  DBMS_OUTPUT.PUT_LINE('------------------------------');

  OPEN c_temp_table_spaces FOR my_sql;
  LOOP
    FETCH c_temp_table_spaces INTO my_tablespace;
    EXIT WHEN c_temp_table_spaces%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(my_tablespace);
  END LOOP;
END;
/

PRO
PRO Tablespace name is case sensitive.

COL temporary_tablespace NEW_VALUE temporary_tablespace FOR A30;
PRO
ACC temporary_tablespace PROMPT 'Temporary tablespace [&&prior_temporary_tablespace.]: ';
SELECT TRIM(NVL('&&temporary_tablespace.', '&&prior_temporary_tablespace.')) temporary_tablespace FROM DUAL;

BEGIN
  IF UPPER('&&temporary_tablespace.') IN ('SYSTEM', 'SYSAUX') THEN
    RAISE_APPLICATION_ERROR(-20105, 'Install failed - SYSTEM/SYSAUX tablespace specified for TEMPORARY tablespace');
  END IF;
END;
/

SET ECHO ON TERM OFF;
ALTER USER trcanlzr TEMPORARY TABLESPACE "&&temporary_tablespace.";
SET ECHO OFF TERM ON;

/* ---------------------------------------------------------------------- */

PRO
PRO Type of TRCA repository
PRO
PRO Create TRCA repository as Temporary or Permanent objects?
PRO Enter T for Temporary or P for Permanent.
PRO T is recommended and default value.
PRO
ACC temporary_or_permanent PROMPT 'Type of TRCA repository [T]: ';
PRO

/* ---------------------------------------------------------------------- */

UNDEFINE default_tablespace temporary_tablespace
UNDEFINE prior_default_tablespace prior_temporary_tablespace

SET ECHO OFF TERM ON VER ON;
PRO
PRO TACUSR completed.
