SPO 02_sqcusr.log;
SET TERM OFF ECHO ON VER OFF SERVEROUT ON SIZE 1000000;
REM
REM $Header: 215187.1 sqcusr.sql 11.4.4.7 2012/07/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqcusr.sql
REM
REM DESCRIPTION
REM   Creates user SQLTXPLAIN and the grants it needs.
REM
REM PRE-REQUISITES
REM   1. To install SQLT you must connect INTERNAL(SYS) as SYSDBA.
REM
REM PARAMETERS
REM   1. Connect Identifier. (optional).
REM      Some restricted-access systems may need to specify
REM      a connect identifier like "@PROD".
REM      This optional parameter allows to enter it. Else,
REM      enter nothing and just hit the "Enter" key.
REM   2. SQLTXPLAIN password (required).
REM      It may be case sensitive in some systems.
REM   3. Default tablespace for user SQLTXPLAIN (required).
REM      You will be presented with a list, then you will
REM      have to enter one tablespace name from that list.
REM   4. Temporary tablespace for user SQLTXPLAIN (required).
REM   5. Main application user of SQLT (optional).
REM      This is the user name that will later execute SQLT.
REM      You can add aditional SQLT users by granting them
REM      role SQLT_USER_ROLE after the tool is installed.
REM   6. Do you have a license for the Oracle Diagnostic or
REM      the Oracle Tuning Pack? (required).
REM      This enables or disables access to licensed
REM      features of the these packages. Defaults to Tuning.
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory.
REM   2. Start SQL*Plus and connect INTERNAL(SYS) as SYSDBA.
REM   3. Execute script sqcusr.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqcusr.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqcreate.sql
REM   2. For possible errors see sqcusr.log file. Some are expected.
REM
SET ECHO ON TERM OFF;

REM
REM Creating SQLTXPLAIN user
REM
BEGIN
  EXECUTE IMMEDIATE('CREATE USER sqltxplain IDENTIFIED BY "&&sqltxplain_password."');
  DBMS_OUTPUT.PUT_LINE('User SQLTXPLAIN created');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('User SQLTXPLAIN could not be created. '||SQLERRM);
END;
/

BEGIN
  EXECUTE IMMEDIATE('ALTER USER sqltxplain IDENTIFIED BY "&&sqltxplain_password."');
  DBMS_OUTPUT.PUT_LINE('User SQLTXPLAIN altered');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('User SQLTXPLAIN could not be altered. '||SQLERRM);
END;
/

/*------------------------------------------------------------------*/

REM
REM Setup default tablespace for user SQLTXPLAIN
REM
ALTER USER sqltxplain DEFAULT TABLESPACE "&&default_tablespace.";
ALTER USER sqltxplain QUOTA UNLIMITED ON "&&default_tablespace.";

REM
REM Setup temporary tablespace for user SQLTXPLAIN
REM
ALTER USER sqltxplain TEMPORARY TABLESPACE "&&temporary_tablespace.";

/*------------------------------------------------------------------*/

REM
REM SQLT_USER_ROLE
REM
DECLARE
  my_count INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO my_count
    FROM dba_roles
   WHERE role = 'SQLT_USER_ROLE';
  IF my_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE ROLE sqlt_user_role';
  END IF;
END;
/

GRANT SQLT_USER_ROLE           TO sqltxplain;

-- needed to invoke sql tuning advisor
GRANT ADVISOR                  TO sqlt_user_role;
-- needed to invoke dbms_metadata from pl/sql
GRANT SELECT_CATALOG_ROLE      TO sqlt_user_role;

PRINT rdbms_release;
BEGIN
  IF :rdbms_release >= 11 THEN
    EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL MANAGEMENT OBJECT TO sqlt_user_role';
  ELSE
    EXECUTE IMMEDIATE 'GRANT CREATE ANY SQL PROFILE TO sqlt_user_role';
    EXECUTE IMMEDIATE 'GRANT ALTER ANY SQL PROFILE  TO sqlt_user_role';
    EXECUTE IMMEDIATE 'GRANT DROP ANY SQL PROFILE   TO sqlt_user_role';
  END IF;
END;
/

REM
REM Utilities privileges for SQLT_USER_ROLE
REM
DECLARE
  PROCEDURE grant_execute (
    p_owner   IN VARCHAR2,
    p_package IN VARCHAR2 )
  IS
    my_count INTEGER;
  BEGIN
    SELECT COUNT(*)
      INTO my_count
      FROM dba_tab_privs
     WHERE owner      = UPPER(p_owner)
       AND table_name = UPPER(p_package)
       AND privilege  = 'EXECUTE'
       AND grantee   IN ('PUBLIC', 'SQLT_USER_ROLE');
     IF my_count = 0 THEN
       EXECUTE IMMEDIATE 'GRANT EXECUTE ON '||p_owner||'.'||p_package||' TO sqlt_user_role';
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SUCCEEDED.');
     ELSE
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SKIPPED.');
     END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' FAILED: '||SQLERRM);
  END grant_execute;
BEGIN
  grant_execute('sys', 'dbms_metadata');
  grant_execute('sys', 'dbms_workload_repository');
  grant_execute('ctxsys', 'ctx_report');
END;
/

GRANT SQLT_USER_ROLE TO &&application_schema.;

/*------------------------------------------------------------------*/

REM
REM System and Role privileges
REM
GRANT ALTER SESSION                 TO sqltxplain;
GRANT ANALYZE ANY                   TO sqltxplain;
GRANT ANALYZE ANY DICTIONARY        TO sqltxplain;
GRANT CREATE JOB                    TO sqltxplain;
GRANT CREATE PROCEDURE              TO sqltxplain;
GRANT CREATE SEQUENCE               TO sqltxplain;
GRANT CREATE SESSION                TO sqltxplain;
GRANT CREATE TABLE                  TO sqltxplain;
GRANT CREATE TYPE                   TO sqltxplain;
GRANT CREATE VIEW                   TO sqltxplain;
GRANT SELECT ANY DICTIONARY         TO sqltxplain;

GRANT ADVISOR                       TO sqltxplain;
GRANT ADMINISTER SQL TUNING SET     TO sqltxplain;
GRANT EXECUTE_CATALOG_ROLE          TO sqltxplain;
GRANT GATHER_SYSTEM_STATISTICS      TO sqltxplain;
GRANT SELECT_CATALOG_ROLE           TO sqltxplain;

PRINT rdbms_release;
BEGIN
  IF :rdbms_release >= 11 THEN
    EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL MANAGEMENT OBJECT TO sqltxplain';
  ELSE
    EXECUTE IMMEDIATE 'GRANT CREATE ANY SQL PROFILE TO sqltxplain';
    EXECUTE IMMEDIATE 'GRANT ALTER ANY SQL PROFILE  TO sqltxplain';
    EXECUTE IMMEDIATE 'GRANT DROP ANY SQL PROFILE   TO sqltxplain';
  END IF;
END;
/

/*------------------------------------------------------------------*/

REM
REM EBS
REM
BEGIN
  EXECUTE IMMEDIATE 'GRANT SELECT ON applsys.fnd_product_groups TO sqltxplain';
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Not an EBS system');
END;
/

/*------------------------------------------------------------------*/

REM
REM Utilities privileges for SQLTXPLAIN
REM
DECLARE
  PROCEDURE grant_execute (
    p_owner   IN VARCHAR2,
    p_package IN VARCHAR2 )
  IS
    my_count INTEGER;
  BEGIN
    SELECT COUNT(*)
      INTO my_count
      FROM dba_tab_privs
     WHERE owner      = UPPER(p_owner)
       AND table_name = UPPER(p_package)
       AND privilege  = 'EXECUTE'
       AND grantee   IN ('PUBLIC', 'SQLT_USER_ROLE', 'SQLTXPLAIN');
     IF my_count = 0 THEN
       EXECUTE IMMEDIATE 'GRANT EXECUTE ON '||p_owner||'.'||p_package||' TO sqltxplain';
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SUCCEEDED.');
     ELSE
       DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' SKIPPED.');
     END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('GRANT EXECUTE ON '||p_owner||'.'||p_package||' FAILED: '||SQLERRM);
  END grant_execute;
BEGIN
  grant_execute('sys', 'dbms_lob');
  grant_execute('sys', 'dbms_random');
  grant_execute('sys', 'dbms_space_admin');
  grant_execute('sys', 'dbms_stats');
  grant_execute('sys', 'utl_raw');
  grant_execute('sys', 'utl_file');
  grant_execute('ctxsys', 'ctx_report');
END;
/

/*------------------------------------------------------------------*/

REM
REM WRI$ views
REM
GRANT SELECT ON sys.wri$_optstat_aux_history      TO sqltxplain;

/*------------------------------------------------------------------*/

REM
REM OPTSTAT tables
REM
GRANT SELECT ON sys.optstat_hist_control$      TO sqltxplain;

PRINT rdbms_release;
BEGIN
  IF :rdbms_release >= 11 THEN
    EXECUTE IMMEDIATE 'GRANT SELECT ON sys.optstat_user_prefs$ TO sqltxplain';
  END IF;
END;
/

/* ---------------------------------------------------------------------- */

REM
REM OL$ views
REM
GRANT SELECT ON outln.ol$      TO sqltxplain;
GRANT SELECT ON outln.ol$hints TO sqltxplain;
GRANT SELECT ON outln.ol$nodes TO sqltxplain;

/*------------------------------------------------------------------*/

REM
REM New system views (extensions)
REM

-- extents
CREATE OR REPLACE VIEW sys.x_$ktfbue AS SELECT * FROM sys.x$ktfbue;
GRANT SELECT ON sys.x_$ktfbue TO sqltxplain;
DECLARE
  my_count INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO my_count
    FROM dba_users
   WHERE username = 'TRCANLZR';
  IF my_count > 0 THEN
    EXECUTE IMMEDIATE 'GRANT SELECT ON sys.x_$ktfbue TO trcanlzr';
  END IF;
END;
/

-- extension to gv$parameter2 but only for cbo parameters and including all cbo hidden parameters
CREATE OR REPLACE VIEW sys.sqlt$_gv$parameter_cbo_v AS
WITH cbo_param AS (
SELECT /*+ materialize */
       pname_qksceserow name
  FROM x$qksceses
 WHERE sid_qksceserow = SYS_CONTEXT('USERENV', 'SID')
)
SELECT x.inst_id,
       x.indx+1 num,
       x.ksppinm name,
       x.ksppity type,
       y.ksppstvl value,
       y.ksppstdvl display_value,
       y.ksppstdf isdefault,
       DECODE(BITAND(x.ksppiflg/256, 1), 1, 'TRUE', 'FALSE') isses_modifiable,
       DECODE(BITAND(x.ksppiflg/65536, 3), 1, 'IMMEDIATE', 2, 'DEFERRED', 3, 'IMMEDIATE', 'FALSE') issys_modifiable,
       DECODE(BITAND(x.ksppiflg, 4), 4, 'FALSE', DECODE(BITAND(x.ksppiflg/65536, 3), 0, 'FALSE', 'TRUE')) isinstance_modifiable,
       DECODE(BITAND(y.ksppstvf, 7), 1, 'MODIFIED', 4,'SYSTEM_MOD', 'FALSE') ismodified,
       DECODE(BITAND(y.ksppstvf, 2), 2, 'TRUE', 'FALSE') isadjusted,
       DECODE(BITAND(x.ksppilrmflg/64, 1), 1, 'TRUE', 'FALSE') isdeprecated,
       DECODE(BITAND(x.ksppilrmflg/268435456, 1), 1, 'TRUE', 'FALSE') isbasic,
       x.ksppdesc description,
       y.ksppstcmnt update_comment,
       x.ksppihash hash
  FROM x$ksppi x,
       x$ksppcv y,
       cbo_param
 WHERE x.indx = y.indx
   AND BITAND(x.ksppiflg, 268435456) = 0
   AND TRANSLATE(x.ksppinm, '_', '#') NOT LIKE '##%'
   AND x.ksppinm = cbo_param.name;

GRANT SELECT ON sys.sqlt$_gv$parameter_cbo_v TO sqltxplain;

-- superset of col$ needed to get property
CREATE OR REPLACE VIEW sys.sqlt$_col$_v
AS
SELECT u.name owner,
       o.name table_name,
       c.name column_name,
       c.obj#,
       c.col#,
       c.segcol#,
       c.segcollength,
       c.offset,
       c.type#,
       c.length,
       c.fixedstorage,
       c.precision#,
       c.scale,
       c.null$,
       c.deflength,
       c.default$,
       c.intcol#,
       c.property,
       c.charsetid,
       c.charsetform,
       c.spare1,
       c.spare2,
       c.spare3,
       c.spare4,
       c.spare5,
       c.spare6
  FROM sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE o.obj# = c.obj#
   AND o.owner# = u.user#
   AND o.type# IN (2, 3, 4);

GRANT SELECT ON sys.sqlt$_col$_v TO sqltxplain;

-- extension to col_usage$ table
CREATE OR REPLACE VIEW sys.sqlt$_dba_col_usage_v AS
SELECT u.name owner,
       o.name table_name,
       c.name column_name,
       cu.equality_preds,
       cu.equijoin_preds,
       cu.nonequijoin_preds,
       cu.range_preds,
       cu.like_preds,
       cu.null_preds,
       cu.timestamp,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       cu.obj# object_id
  FROM sys.col_usage$ cu,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE cu.obj# = c.obj#
   AND cu.intcol# = c.intcol#
   AND cu.obj# = o.obj#
   AND o.type# = 2
   AND o.owner# = u.user#;

GRANT SELECT ON sys.sqlt$_dba_col_usage_v TO sqltxplain;

-- this is where statistics history is controlled
GRANT SELECT, UPDATE ON sys.optstat_hist_control$ TO sqltxplain;

-- extension to an hybrid between dba_tab_stats_history, dba_tab_pending_stats and wri$_optstat_tab_history
CREATE OR REPLACE VIEW sys.sqlt$_dba_tab_stats_vers_v AS
SELECT u.name owner,
       o.name table_name,
       NULL partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'TABLE' object_type,
       h.rowcnt num_rows,
       h.blkcnt blocks,
       h.avgrln avg_row_len,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_tab_history h,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = o.obj#
   AND o.type# = 2
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       o.name table_name,
       o.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       h.rowcnt num_rows,
       h.blkcnt blocks,
       h.avgrln avg_row_len,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_tab_history h,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = o.obj#
   AND o.type# = 19
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       osp.name table_name,
       ocp.subname partition_name,
       osp.subname subpartition_name,
       h.obj# object_id,
       'SUBPARTITION' object_type,
       h.rowcnt num_rows,
       h.blkcnt blocks,
       h.avgrln avg_row_len,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_tab_history h,
       sys.obj$ osp,
       sys.tabsubpart$ tsp,
       sys.obj$ ocp,
       sys.user$ u
 WHERE h.obj# = osp.obj#
   AND osp.type# = 34
   AND osp.obj# = tsp.obj#
   AND tsp.pobj# = ocp.obj#
   AND osp.owner# = u.user#;

GRANT SELECT ON sys.sqlt$_dba_tab_stats_vers_v TO sqltxplain;
GRANT SELECT, INSERT, DELETE ON sys.wri$_optstat_tab_history TO sqltxplain;

-- extension to dba_ind_pending_stats and wri$_optstat_ind_history
CREATE OR REPLACE VIEW sys.sqlt$_dba_ind_stats_vers_v AS
SELECT ui.name owner,
       oi.name index_name,
       ut.name table_owner,
       ot.name table_name,
       NULL partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'INDEX' object_type,
       h.leafcnt leaf_blocks,
       h.distkey distinct_keys,
       h.lblkkey avg_leaf_blocks_per_key,
       h.dblkkey avg_data_blocks_per_key,
       h.clufac clustering_factor,
       h.rowcnt num_rows,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_ind_history h,
       sys.ind$ i,
       sys.obj$ oi,
       sys.user$ ui,
       sys.obj$ ot,
       sys.user$ ut
 WHERE h.obj# = i.obj#
   AND i.type# IN (1, 2, 3, 4, 6, 7, 8)
   AND BITAND(i.flags, 4096) = 0
   AND i.obj# = oi.obj#
   AND oi.namespace = 4
   AND oi.remoteowner IS NULL
   AND oi.linkname IS NULL
   AND oi.owner# = ui.user#
   AND i.bo# = ot.obj#
   AND ot.owner# = ut.user#
 UNION ALL
SELECT ui.name owner,
       oi.name index_name,
       ut.name table_owner,
       ot.name table_name,
       oi.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       h.leafcnt leaf_blocks,
       h.distkey distinct_keys,
       h.lblkkey avg_leaf_blocks_per_key,
       h.dblkkey avg_data_blocks_per_key,
       h.clufac clustering_factor,
       h.rowcnt num_rows,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_ind_history h,
       sys.indpart$ ip,
       sys.ind$ i,
       sys.obj$ oi,
       sys.user$ ui,
       sys.obj$ ot,
       sys.user$ ut
 WHERE h.obj# = ip.obj#
   AND ip.bo# = i.obj#
   AND i.type# IN (1, 2, 3, 4, 6, 7, 8)
   AND BITAND(i.flags, 4096) = 0
   AND ip.obj# = oi.obj#
   AND oi.namespace = 4
   AND oi.remoteowner IS NULL
   AND oi.linkname IS NULL
   AND oi.owner# = ui.user#
   AND i.bo# = ot.obj#
   AND ot.owner# = ut.user#
 UNION ALL
SELECT ui.name owner,
       oi.name index_name,
       ut.name table_owner,
       ot.name table_name,
       oi.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       h.leafcnt leaf_blocks,
       h.distkey distinct_keys,
       h.lblkkey avg_leaf_blocks_per_key,
       h.dblkkey avg_data_blocks_per_key,
       h.clufac clustering_factor,
       h.rowcnt num_rows,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_ind_history h,
       sys.indcompart$ ip,
       sys.ind$ i,
       sys.obj$ oi,
       sys.user$ ui,
       sys.obj$ ot,
       sys.user$ ut
 WHERE h.obj# = ip.obj#
   AND ip.bo# = i.obj#
   AND i.type# IN (1, 2, 3, 4, 6, 7, 8)
   AND BITAND(i.flags, 4096) = 0
   AND ip.obj# = oi.obj#
   AND oi.namespace = 4
   AND oi.remoteowner IS NULL
   AND oi.linkname IS NULL
   AND oi.owner# = ui.user#
   AND i.bo# = ot.obj#
   AND ot.owner# = ut.user#
 UNION ALL
SELECT ui.name owner,
       oi.name index_name,
       ut.name table_owner,
       ot.name table_name,
       os.name partition_name,
       os.subname subpartition_name,
       h.obj# object_id,
       'SUBPARTITION' object_type,
       h.leafcnt leaf_blocks,
       h.distkey distinct_keys,
       h.lblkkey avg_leaf_blocks_per_key,
       h.dblkkey avg_data_blocks_per_key,
       h.clufac clustering_factor,
       h.rowcnt num_rows,
       h.samplesize sample_size,
       h.analyzetime last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_ind_history h,
       sys.indsubpart$ isp,
       sys.indcompart$ icp,
       sys.ind$ i,
       sys.obj$ os,
       sys.obj$ oi,
       sys.user$ ui,
       sys.obj$ ot,
       sys.user$ ut
 WHERE h.obj# = isp.obj#
   AND isp.pobj# = icp.obj#
   AND icp.bo# = i.obj#
   AND i.type# IN (1, 2, 3, 4, 6, 7, 8)
   AND BITAND(i.flags, 4096) = 0
   AND isp.obj# = os.obj#
   AND os.type# = 35
   AND os.namespace = 4
   AND os.remoteowner IS NULL
   AND os.linkname IS NULL
   AND i.obj# = oi.obj#
   AND oi.type# = 1
   AND oi.owner# = ui.user#
   AND i.bo# = ot.obj#
   AND ot.type# = 2
   AND ot.owner# = ut.user#;

GRANT SELECT ON sys.sqlt$_dba_ind_stats_vers_v TO sqltxplain;
GRANT SELECT, INSERT, DELETE ON sys.wri$_optstat_ind_history TO sqltxplain;

-- extension to dba_col_pending_stats and wri$_optstat_histhead_history
CREATE OR REPLACE VIEW sys.sqlt$_dba_col_stats_vers_v AS
SELECT u.name owner,
       o.name table_name,
       NULL partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'TABLE' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.distcnt num_distinct,
       h.lowval low_value,
       h.hival high_value,
       h.null_cnt num_nulls,
       h.avgcln avg_col_len,
       h.timestamp# last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histhead_history h,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 2
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       o.name table_name,
       o.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.distcnt num_distinct,
       h.lowval low_value,
       h.hival high_value,
       h.null_cnt num_nulls,
       h.avgcln avg_col_len,
       h.timestamp# last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histhead_history h,
       sys.tabpart$ t,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = t.obj#
   AND t.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 19
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       o.name table_name,
       o.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.distcnt num_distinct,
       h.lowval low_value,
       h.hival high_value,
       h.null_cnt num_nulls,
       h.avgcln avg_col_len,
       h.timestamp# last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histhead_history h,
       sys.tabcompart$ t,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = t.obj#
   AND t.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 19
   AND o.owner# = u.user#
 UNION ALL
SELECT us.name owner,
       op.name table_name,
       op.subname partition_name,
       os.subname subpartition_name,
       h.obj# object_id,
       'SUBPARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.distcnt num_distinct,
       h.lowval low_value,
       h.hival high_value,
       h.null_cnt num_nulls,
       h.avgcln avg_col_len,
       h.timestamp# last_analyzed,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histhead_history h,
       sys.tabsubpart$ tsp,
       sys.tabcompart$ tcp,
       sys.col$ c,
       sys.obj$ os,
       sys.user$ us,
       sys.obj$ op
 WHERE h.obj# = tsp.obj#
   AND tsp.pobj# = tcp.obj#
   AND tcp.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND tsp.obj# = os.obj#
   AND os.type# = 34
   AND os.owner# = us.user#
   AND tcp.obj# = op.obj#
   AND op.type# = 19;

GRANT SELECT ON sys.sqlt$_dba_col_stats_vers_v TO sqltxplain;
GRANT SELECT, INSERT, DELETE ON sys.wri$_optstat_histhead_history TO sqltxplain;

-- extension to dba_tab_histgrm_pending_stats and wri$_optstat_histgrm_history
CREATE OR REPLACE VIEW sys.sqlt$_dba_hgrm_stats_vers_v AS
SELECT u.name owner,
       o.name table_name,
       NULL partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'TABLE' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.bucket endpoint_number,
       h.endpoint endpoint_value,
       h.epvalue endpoint_actual_value,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histgrm_history h,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 2
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       o.name table_name,
       o.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.bucket endpoint_number,
       h.endpoint endpoint_value,
       h.epvalue endpoint_actual_value,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histgrm_history h,
       sys.tabpart$ t,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = t.obj#
   AND t.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 19
   AND o.owner# = u.user#
 UNION ALL
SELECT u.name owner,
       o.name table_name,
       o.subname partition_name,
       NULL subpartition_name,
       h.obj# object_id,
       'PARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.bucket endpoint_number,
       h.endpoint endpoint_value,
       h.epvalue endpoint_actual_value,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histgrm_history h,
       sys.tabcompart$ t,
       sys.col$ c,
       sys.obj$ o,
       sys.user$ u
 WHERE h.obj# = t.obj#
   AND t.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND h.obj# = o.obj#
   AND o.type# = 19
   AND o.owner# = u.user#
 UNION ALL
SELECT us.name owner,
       op.name table_name,
       op.subname partition_name,
       os.subname subpartition_name,
       h.obj# object_id,
       'SUBPARTITION' object_type,
       c.name column_name,
       DECODE(c.col#, 0, TO_NUMBER(NULL), c.col#) column_id,
       h.bucket endpoint_number,
       h.endpoint endpoint_value,
       h.epvalue endpoint_actual_value,
       CASE WHEN h.savtime < SYSTIMESTAMP THEN h.savtime END save_time,
       CASE WHEN h.savtime > SYSTIMESTAMP THEN 'PENDING' ELSE 'HISTORY' END version_type,
       h.*
  FROM sys.wri$_optstat_histgrm_history h,
       sys.tabsubpart$ tsp,
       sys.tabcompart$ tcp,
       sys.col$ c,
       sys.obj$ os,
       sys.user$ us,
       sys.obj$ op
 WHERE h.obj# = tsp.obj#
   AND tsp.pobj# = tcp.obj#
   AND tcp.bo# = c.obj#
   AND h.intcol# = c.intcol#
   AND tsp.obj# = os.obj#
   AND os.type# = 34
   AND os.owner# = us.user#
   AND tcp.obj# = op.obj#
   AND op.type# = 19;

GRANT SELECT ON sys.sqlt$_dba_hgrm_stats_vers_v TO sqltxplain;
GRANT SELECT, INSERT, DELETE ON sys.wri$_optstat_histgrm_history TO sqltxplain;

-- used by sqltxecute.sql and sqltxplain.sql
CREATE OR REPLACE VIEW sys.sqlt$_my_v$session AS
SELECT prev_hash_value, prev_sql_id, prev_child_number
  FROM v$session
 WHERE sid = SYS_CONTEXT('USERENV', 'SID')
   AND status = 'ACTIVE';

GRANT SELECT ON sys.sqlt$_my_v$session TO &&role_name.;

-- used by sqltxecute.sql and sqltxplain.sql
CREATE OR REPLACE VIEW sys.sqlt$_my_v$sql AS
SELECT sql_id, child_number, sql_text FROM v$sql;

GRANT SELECT ON sys.sqlt$_my_v$sql TO &&role_name.;

/*------------------------------------------------------------------*/

WHENEVER SQLERROR CONTINUE;

/*------------------------------------------------------------------*/

REM
REM SQLT_USER_ROLE to prior users of SQLT
REM
BEGIN
  FOR i IN (SELECT DISTINCT username
              FROM sqltxplain.sqlt$_sql_statement
             WHERE username NOT IN ('SYS', 'SQLTXPLAIN'))
  LOOP
    EXECUTE IMMEDIATE 'GRANT SQLT_USER_ROLE TO '||i.username;
  END LOOP;
END;
/

/*------------------------------------------------------------------*/

UNDEFINE main_application_schema application_schema
UNDEFINE default_tablespace temporary_tablespace
UNDEFINE prior_default_tablespace prior_temporary_tablespace
SET ECHO OFF TERM ON VER ON;
PRO
PRO SQCUSR completed. Some errors are expected.
