SET ECHO ON TERM OFF NUMF "";
REM
REM $Header: 224270.1 tadrop.sql 11.4.4.1 2012/01/02 csierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   tadrop.sql
REM
REM DESCRIPTION
REM   This script uninstalls a prior version of the TRCANLZR tool
REM   droping first existing TRCANLZR objects, then the TRCANLZR
REM   user itself.
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to trca/install directory
REM   2. Start SQL*Plus connecting INTERNAL (SYS) as SYSDBA
REM   3. Execute script tadrop.sql
REM
REM EXAMPLE
REM   # cd trca/install
REM   # sqlplus /nolog
REM   SQL> connect / as sysdba
REM   SQL> start tadrop.sql
REM
REM NOTES
REM   1. This script is executed automatically by tacreate.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM OFF;
DEF tool_owner = "TRCANLZR";
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop script failed - tadrop.sql should be executed connected as SYS, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET TERM ON;
PRO Uninstalling TRCA, please wait
SET TERM OFF;

@@tadobj.sql
@@tadusr.sql

PRO TADROP completed.
