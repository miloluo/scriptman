SPO 06_sqcold.log;
SET TERM OFF ECHO ON VER OFF SERVEROUT ON;
REM
REM $Header: 215187.1 sqcold.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqcold.sql
REM
REM DESCRIPTION
REM   Creates old SQLT schema objects owned by SQLTXPLAIN.
REM
REM PRE-REQUISITES
REM   1. Connect as SQLTXPLAIN
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting as SQLTXPLAIN
REM   3. Execute script sqcold.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus sqltxplain
REM   SQL> START sqcold.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqcreate.sql
REM   2. For possible errors see sqcold.log file
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common

ALTER SESSION SET PLSQL_CODE_TYPE = INTERPRETED;
ALTER SESSION SET NLS_LENGTH_SEMANTICS = CHAR;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET ECHO OFF TERM ON;

BEGIN
  IF USER <> 'SQLTXPLAIN' THEN
    RAISE_APPLICATION_ERROR(-20100, 'SQLT schema objects creation failed. Connect as SQLTXPLAIN, not as '||USER);
  END IF;
END;
/

PRO
PRO ... creating some old SQLT schema objects, please wait

SET ECHO ON TERM OFF;
WHENEVER SQLERROR CONTINUE;

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_statement
( statement_id                 NUMBER ,
  statid                       VARCHAR2(30) , -- 10.0
  /* Environment */
  sqlt_date                    DATE, -- 11.2.9
  method                       VARCHAR2(30), -- 10.7
  script                       VARCHAR2(64), -- 10.7
  execution_id                 NUMBER, -- 11.1 deprecated 11.2.8
  input_filename               VARCHAR2(128),
  host_name_short              VARCHAR2(128),
  cpu_count                    NUMBER,
  rac                          VARCHAR2(16), -- 11.2.3
  database_id                  NUMBER,
  database_name_short          VARCHAR2(128),
  instance_number              NUMBER,
  instance_name_short          VARCHAR2(128),
  platform                     VARCHAR2(256),
  product_version              VARCHAR2(256),
  rdbms_version                VARCHAR2(32),
  rdbms_version_short          VARCHAR2(32),
  rdbms_release                NUMBER,  -- 11.1
  language                     VARCHAR2(256),
  apps_release                 VARCHAR2(64),
  apps_system_name             VARCHAR2(32),
  apps_multi_org_flag          CHAR(1),
  /* SQL identification */
  hash_value                   NUMBER,
  inst_id                      NUMBER, -- 10.7
  address                      VARCHAR2(16),
  child_number                 NUMBER, -- 10.0
  sql_id                       VARCHAR2(13), -- 10.0
  signature                    VARCHAR2(64), -- 10.7 Stored Outlines
  stored_outline_name          VARCHAR2(32), -- 11.2.9
  signaturen                   NUMBER, -- 11.2.6 SQL Profile
  sql_profile_name             VARCHAR2(32), -- 11.2.9
  command_type                 NUMBER, -- 10.0
  plan_source                  VARCHAR2(30), -- 11.2.8 'V$SQL_PLAN', 'GV$SQL_PLAN', 'DBA_HIST_SQL_PLAN', 'EXPLAIN PLAN FOR'
  plan_hash_value              NUMBER, -- 10.0
  sqlt_plan_hash_value         NUMBER, -- created in 10.7.4, deprecated in 11.3.1.1
  best_plan_hash_value         NUMBER, -- 11.3.1.0
  best_plan_avg_buffer_gets    NUMBER, -- 11.3.1.0
  best_plan_avg_cpu_time       NUMBER, -- 11.3.1.0
  best_plan_avg_elapsed_time   NUMBER, -- 11.3.1.0
  best_plan_executions         NUMBER, -- 11.3.1.0
  best_plan_cost               NUMBER, -- 11.3.1.0
  best_plan_source             VARCHAR2(30), -- 11.3.1.0
  worst_plan_hash_value        NUMBER, -- 11.3.1.0
  worst_plan_avg_buffer_gets   NUMBER, -- 11.3.1.0
  worst_plan_avg_cpu_time      NUMBER, -- 11.3.1.0
  worst_plan_avg_elapsed_time  NUMBER, -- 11.3.1.0
  worst_plan_executions        NUMBER, -- 11.3.1.0
  worst_plan_source            VARCHAR2(30), -- 11.3.1.0
  worst_plan_cost              NUMBER, -- 11.3.1.0
  /* SQL Text */
  sql_source                   VARCHAR2(30), -- 11.2.5 'V$SQL', 'GV$SQL', 'DBA_HIST_SQLSTAT', 'FILE', 'UNKNOWN'
  sql_length                   NUMBER,
  sql_text                     VARCHAR2(4000),
  sql_text_clob                CLOB, -- 10.7
  sql_text_clob_stripped       CLOB, -- 11.2.9
  /* Plan */
  explained                    CHAR(1),
  explain_plan_error           VARCHAR2(4000),
  generated_10053              CHAR(1), -- 10.0
  rows_filled                  CHAR(1), -- 11.0.3
  cost                         NUMBER, -- 10.7.4
  cpu_cost                     NUMBER, -- 10.7.4
  io_cost                      NUMBER, -- 10.7.4
  cardinality                  NUMBER, -- 10.7.4
  bytes                        NUMBER, -- 10.7.4
  estimated_secs               NUMBER, -- 11.2.3
  actual_secs                  NUMBER, -- 11.2.3
  /* Audit Trail */
  user_id                      NUMBER,
  username                     VARCHAR2(30),
  temporary_tablespace         VARCHAR2(30), -- 10.2
  tool_start_date              DATE,
  tool_end_date                DATE,
  cbo_stats_schema_objects     NUMBER, -- 11.2.9.1
  cbo_stats_fixed_objects      NUMBER, -- 11.2.9.1
  fixed_objects_in_plan        NUMBER, -- 11.2.9.1
  /* DBMS_STATS Parameters */
  param_autostats_target       VARCHAR2(256), -- 11.2.9.6
  param_publish                VARCHAR2(256), -- 11.2.9.6
  param_incremental            VARCHAR2(256), -- 11.2.9.6
  param_stale_percent          VARCHAR2(256), -- 11.2.9.6
  param_estimate_percent       VARCHAR2(256), -- 10.3
  param_degree                 VARCHAR2(256), -- 10.3
  param_cascade                VARCHAR2(256), -- 10.3
  param_no_invalidate          VARCHAR2(256), -- 10.3
  param_method_opt             VARCHAR2(256), -- 10.3
  param_granularity            VARCHAR2(256), -- 10.3
  to_estimate_percent_type     NUMBER, -- 10.3
  to_degree_type               NUMBER, -- 10.3
  to_cascade_type              VARCHAR2(8), -- 10.3
  to_no_invalidate_type        VARCHAR2(8), -- 10.3
  /* DBA_SCHEDULER_JOBS GATHER_STATS_JOB 10g */
  job_name                     VARCHAR2(32), -- 10.3
  job_program_name             VARCHAR2(4000), -- 10.3
  job_schedule_name            VARCHAR2(4000), -- 10.3
  -- job_schedule_type            VARCHAR2(16),  -- 10.3 deprecated 10.7.2
  job_class                    VARCHAR2(32), -- 10.3
  job_enabled                  VARCHAR2(8), -- 10.3
  job_state                    VARCHAR2(16), -- 10.3
  job_priority                 NUMBER, -- 10.3
  job_run_count                NUMBER, -- 10.3
  job_retry_count              NUMBER, -- 10.3
  job_last_start_date          VARCHAR2(256), -- 10.3
  job_last_run_duration        VARCHAR2(256), -- 10.3
  job_stop_on_window_close     VARCHAR2(8), -- 10.3
  /* DBA_AUTOTASK_CLIENT "auto optimizer stats collection" 11g */
  client_name                  VARCHAR2(64), -- 11.2.9.6
  status                       VARCHAR2(8), -- 11.2.9.6
  consumer_group               VARCHAR2(30), -- 11.2.9.6
  client_tag                   VARCHAR2(2), -- 11.2.9.6
  priority_override            VARCHAR2(7), -- 11.2.9.6
  attributes                   VARCHAR2(4000), -- 11.2.9.6
  window_group                 VARCHAR2(64), -- 11.2.9.6
  service_name                 VARCHAR2(64), -- 11.2.9.6
  resource_percentage          NUMBER, -- 11.2.9.6
  use_resource_estimates       VARCHAR2(5), -- 11.2.9.6
  mean_job_duration            INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
  mean_job_cpu                 INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
  mean_job_attempts            NUMBER, -- 11.2.9.6
  mean_incoming_tasks_7_days   NUMBER, -- 11.2.9.6
  mean_incoming_tasks_30_days  NUMBER, -- 11.2.9.6
  total_cpu_last_7_days        INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
  total_cpu_last_30_days       INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
  max_duration_last_7_days     INTERVAL DAY(3) TO SECOND(0), -- 11.2.9.6
  max_duration_last_30_days    INTERVAL DAY(3) TO SECOND(0), -- 11.2.9.6
  window_duration_last_7_days  INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
  window_duration_last_30_days INTERVAL DAY(9) TO SECOND(9), -- 11.2.9.6
 /* important CBO init.ora params */
  optimizer_features_enable    VARCHAR2(32), -- 11.2.4
  db_block_size                NUMBER, -- 11.1.5
  /* System Statistics */
  cpuspeednw                   NUMBER, -- 11.2.4
  cpuspeed                     NUMBER, -- 11.1.5
  ioseektim                    NUMBER, -- 11.1.5
  iotfrspeed                   NUMBER, -- 11.1.5
  mbrc                         NUMBER, -- 11.1.5
  sreadtim                     NUMBER, -- 11.1.5
  mreadtim                     NUMBER, -- 11.1.5
  maxthr                       NUMBER, -- 11.1.5
  slavethr                     NUMBER, -- 11.1.5
  cpu_cost_scaling_factor      NUMBER, -- 11.1.5
  /* File Names */
  file_sqlt_main               VARCHAR2(256), -- 11.2.0
  file_sqlt_frames             VARCHAR2(256), -- 11.2.0
  file_sqlt_metadata           VARCHAR2(256), -- 11.2.0
  file_sqlt_setenv             VARCHAR2(256), -- 11.2.4
  file_sqlt_readme             VARCHAR2(256), -- 11.2.4
  file_sqlt_trace_udump        VARCHAR2(256), -- 11.2.1
  file_sqlt_trace              VARCHAR2(256), -- 11.2.0
  file_sqlt_trace_udump_10046  VARCHAR2(256), -- 11.3.0.0
  file_sqlt_trace_10046        VARCHAR2(256), -- 11.3.0.0
  file_sqlt_trace_udump_10053  VARCHAR2(256), -- 11.3.0.0
  file_sqlt_trace_10053        VARCHAR2(256), -- 11.3.0.0
  file_sqlt_lite               VARCHAR2(256), -- 11.2.0
  file_sqlt_tcscript           VARCHAR2(256), -- 11.2.9
  file_sqlt_tcsql              VARCHAR2(256), -- 11.2.9
  file_sqlt_tcbuilder          VARCHAR2(256), -- 11.2.9
  file_sqlt_xplore_script      VARCHAR2(256), -- 11.2.9.5 deprecated 11.3.0.1
  file_sqlt_xplore_report      VARCHAR2(256), -- 11.2.9.5 deprecated 11.3.0.1
  file_sqlt_exp_params         VARCHAR2(256), -- 11.3.0.1
  file_sqlt_profile            VARCHAR2(256), -- 11.3.0.1
  file_trcanlzr_html           VARCHAR2(256), -- 11.2.0
  file_trcanlzr_txt            VARCHAR2(256), -- 11.2.0
  file_trcanlzr_log            VARCHAR2(256) -- 11.2.0
);

ALTER TABLE sqlt$_statement ADD (worst_plan_hash_value NUMBER);

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_plan_table (
  statement_id               VARCHAR2(30) ,
  plan_id                    NUMBER,
  timestamp                  DATE,
  remarks                    VARCHAR2(4000),
  operation                  VARCHAR2(30),
  options                    VARCHAR2(255),
  object_node                VARCHAR2(128),
  object_owner               VARCHAR2(30),
  object_name                VARCHAR2(30),
  object_alias               VARCHAR2(65),
  object_instance            NUMBER,
  object_type                VARCHAR2(30),
  optimizer                  VARCHAR2(255),
  search_columns             NUMBER,
  id                         NUMBER ,
  parent_id                  NUMBER,
  depth                      NUMBER,
  position                   NUMBER,
  cost                       NUMBER,
  cost_cont                  NUMBER, -- 11.3.1.0
  cardinality                NUMBER,
  bytes                      NUMBER,
  other_tag                  VARCHAR2(255),
  partition_start            VARCHAR2(255),
  partition_stop             VARCHAR2(255),
  partition_id               NUMBER,
  other                      CLOB,
  other_xml                  CLOB, -- 10.0
  distribution               VARCHAR2(30),
  cpu_cost                   NUMBER,
  io_cost                    NUMBER,
  temp_space                 NUMBER,
  access_predicates          VARCHAR2(4000),
  filter_predicates          VARCHAR2(4000),
  projection                 VARCHAR2(4000),
  time                       NUMBER,
  time_cont                  NUMBER, -- 11.3.1.0
  qblock_name                VARCHAR2(30),
  object#                    NUMBER, -- 10.0
  execution_order            NUMBER,
  indent                     NUMBER,
  executions                 NUMBER, -- 11.3.1.0
  last_starts                NUMBER, -- 11.2.7
  starts                     NUMBER, -- 11.2.7
  last_output_rows           NUMBER, -- 11.0.3
  output_rows                NUMBER, -- 11.0.3
  last_cr_buffer_gets        NUMBER, -- 11.3.1.0
  last_cr_buffer_gets_cont   NUMBER, -- 11.3.1.0
  cr_buffer_gets             NUMBER, -- 11.3.1.0
  cr_buffer_gets_cont        NUMBER, -- 11.3.1.0
  last_cu_buffer_gets        NUMBER, -- 11.3.1.0
  last_cu_buffer_gets_cont   NUMBER, -- 11.3.1.0
  cu_buffer_gets             NUMBER, -- 11.3.1.0
  cu_buffer_gets_cont        NUMBER, -- 11.3.1.0
  last_disk_reads            NUMBER, -- 11.3.1.0
  last_disk_reads_cont       NUMBER, -- 11.3.1.0
  disk_reads                 NUMBER, -- 11.3.1.0
  disk_reads_cont            NUMBER, -- 11.3.1.0
  last_disk_writes           NUMBER, -- 11.3.1.0
  last_disk_writes_cont      NUMBER, -- 11.3.1.0
  disk_writes                NUMBER, -- 11.3.1.0
  disk_writes_cont           NUMBER, -- 11.3.1.0
  last_elapsed_time          NUMBER, -- 11.3.1.0
  last_elapsed_time_cont     NUMBER, -- 11.3.1.0
  elapsed_time               NUMBER, -- 11.3.1.0
  elapsed_time_cont          NUMBER, -- 11.3.1.0
  statid                     VARCHAR2(30) DEFAULT 'SQLT' -- 11.2.9
);

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_parameter2 ( -- 10.6.3
  statement_id               VARCHAR2(30) ,
  source                     VARCHAR2(32) ,
  this_instance              CHAR(1) ,
  inst_id                    NUMBER ,
  num                        NUMBER ,
  ordinal                    NUMBER ,
  name                       VARCHAR2(80) ,
  type                       NUMBER,
  value                      VARCHAR2(512),
  display_value              VARCHAR2(512),
  is_default                 VARCHAR2(16),
  is_system_modifiable       VARCHAR2(16),
  is_instance_modifiable     VARCHAR2(16),
  is_session_modifiable      VARCHAR2(16),
  is_modified                VARCHAR2(16),
  is_adjusted                VARCHAR2(16),
  is_deprecated              VARCHAR2(16),
  description                VARCHAR2(256),
  child_number               NUMBER, -- deprecated on 11.2.4
  optimizer_feature_enable   VARCHAR2(32), -- 11.2.4
  statid                     VARCHAR2(30) -- 11.2.9
);

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_indexes AS
SELECT
  1 statement_id,
  RPAD('A', 30) statid,
  owner,
  index_name,
  tablespace_name,
  index_type,
  table_owner,
  table_name,
  uniqueness,
  ini_trans,
  max_trans,
  freelists,
  freelist_groups,
  logging,
  blevel,
  leaf_blocks,
  distinct_keys,
  avg_leaf_blocks_per_key,
  avg_data_blocks_per_key,
  clustering_factor,
  status,
  num_rows,
  sample_size,
  last_analyzed,
  degree,
  partitioned,
  temporary,
  global_stats,
  user_stats, -- 11.2.9.6
  domidx_status,
  funcidx_status,
  ityp_owner, -- 11.3.0.1
  ityp_name -- 11.3.0.1
FROM dba_indexes
WHERE 1 = 0;

ALTER TABLE sqlt$_indexes ADD (object_id NUMBER);
ALTER TABLE sqlt$_indexes ADD (segment_blocks NUMBER);
-- max_ix_sel = ((#Blks / MBRC) * (mreadtim / sreadtim) - LVLS)/(#LB + CLUF)
ALTER TABLE sqlt$_indexes ADD (max_ix_sel NUMBER);
ALTER TABLE sqlt$_indexes ADD (columns_count NUMBER);
ALTER TABLE sqlt$_indexes ADD (leading_col_id NUMBER);
ALTER TABLE sqlt$_indexes ADD (indexed_col_ids VARCHAR2(4000));
ALTER TABLE sqlt$_indexes ADD (indexed_col_ids2 VARCHAR2(4000));
ALTER TABLE sqlt$_indexes ADD (indexed_columns VARCHAR2(4000));
ALTER TABLE sqlt$_indexes ADD (in_operations VARCHAR2(4000));
ALTER TABLE sqlt$_indexes ADD (metadata CLOB);
ALTER TABLE sqlt$_indexes ADD (metadata_transformed CLOB);
ALTER TABLE sqlt$_indexes ADD (metadata_cleaned CLOB);
ALTER TABLE sqlt$_indexes ADD (ityp_name VARCHAR2(30));
ALTER TABLE sqlt$_indexes ADD (ityp_owner VARCHAR2(30));

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_ind_columns AS
SELECT
  1 statement_id,
  RPAD('A', 30) statid,
  index_owner,
  index_name,
  table_owner,
  table_name,
  column_name,
  column_position,
  column_length,
  char_length,
  descend
FROM dba_ind_columns
WHERE 1 = 0;

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_tab_columns AS
SELECT
  1 statement_id,
  RPAD('A', 30) statid,
  owner,
  table_name,
  column_name,
  column_id,
  data_type,
  data_type_mod,
  data_type_owner,
  data_length,
  data_precision,
  data_scale,
  nullable,
  character_set_name,
  char_length,
  char_used,
  sample_size,
  last_analyzed,
  global_stats,
  user_stats,
  num_nulls,
  num_distinct,
  density,
  avg_col_len,
  low_value,
  high_value,
  num_buckets
FROM dba_tab_columns
WHERE 1 = 0;

ALTER TABLE sqlt$_tab_columns ADD (index_count NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (leading_index_count NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (hidden_column VARCHAR2(3));
ALTER TABLE sqlt$_tab_columns ADD (histogram VARCHAR2(16));
ALTER TABLE sqlt$_tab_columns ADD (qualified_col_name VARCHAR2(4000));
ALTER TABLE sqlt$_tab_columns ADD (data_default VARCHAR2(4000));
ALTER TABLE sqlt$_tab_columns ADD (low_value_boiled VARCHAR2(128));
ALTER TABLE sqlt$_tab_columns ADD (high_value_boiled VARCHAR2(128));
ALTER TABLE sqlt$_tab_columns ADD (low_endpoint_number NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (high_endpoint_number NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (popular_value_count NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (buckets_popular_value NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (new_density NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (equality_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (equijoin_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (nonequijoin_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (range_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (like_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (null_preds NUMBER);
ALTER TABLE sqlt$_tab_columns ADD (timestamp DATE);
ALTER TABLE sqlt$_tab_columns ADD (predicates NUMBER);
-- 11.2.9.6
ALTER TABLE sqlt$_tab_columns ADD (mutating_num_buckets VARCHAR2(3));
-- 11.2.9.6
ALTER TABLE sqlt$_tab_columns ADD (buckets_history VARCHAR2(4000));
-- 11.3.1.0 values are null and 'Y'
ALTER TABLE sqlt$_tab_columns ADD (in_predicates VARCHAR2(1));

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_other_xml_hints (
  statement_id               NUMBER        ,
  statid                     VARCHAR2(30)   ,
  plan_hash_value            NUMBER         ,
  line_num                   NUMBER        ,
  hint                       VARCHAR2(2000)
);

/* ------------------------------------------------------------------------- */

CREATE TABLE sqlt$_other_xml (
  statement_id               NUMBER        ,
  statid                     VARCHAR2(30)   ,
  plan_hash_value            NUMBER         ,
  plan_source                VARCHAR2(30)   , -- 'DBA_HIST_SQL_PLAN', 'GV$SQL_PLAN', 'V$SQL_PLAN', 'EXPLAIN PLAN FOR'
  sql_id                     VARCHAR2(13)   ,
  hash_value                 NUMBER,                  -- plans out of DBA_HIST_SQL_PLAN have no hash_value
  cost                       NUMBER,                  -- 11.2.9.6
  signature                  NUMBER,                  -- in case signature could not be generated
  sql_text                   VARCHAR2(4000) ,
  sql_text_clob              CLOB           ,
  other_xml                  CLOB
);

/* ------------------------------------------------------------------------- */


SET ECHO OFF VER ON TERM ON;
PRO
PRO SQCOLD completed. Some errors are expected.
SPO OFF;
