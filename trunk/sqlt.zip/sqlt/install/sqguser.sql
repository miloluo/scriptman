SET ECHO ON TERM OFF;
REM
REM $Header: 215187.1 sqguser.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqguser.sql
REM
REM DESCRIPTION
REM   This script creates some grants to the users of SQLTXPLAIN
REM
REM PRE-REQUISITES
REM   1. This script must be executed connected INTERNAL (SYS) as
REM      SYSDBA
REM
REM PARAMETERS
REM   1. Application user executing SQLTXPLAIN (required)
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory.
REM   2. Start SQL*Plus and connect INTERNAL(SYS) as SYSDBA.
REM   3. Execute script sqguser.sql.
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqguser.sql [application user executing SQLTXPLAIN]
REM   SQL> START sqguser.sql APPS
REM   SQL> START sqguser.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER <> 'SYS' THEN
    RAISE_APPLICATION_ERROR(-20100, 'Garnt failed. Connect as SYS, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

/* ---------------------------------------------------------------------- */

PRO
PRO Parameter 1: application user executing SQLTXPLAIN (required)
PRO
DEF application_schema = '&1';

GRANT SQLT_USER_ROLE TO &&application_schema.;

UNDEFINE application_schema
PRO
PRO SQCUSR completed. Some errors are expected.
