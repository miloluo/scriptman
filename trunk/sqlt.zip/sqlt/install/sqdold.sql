SET ECHO ON TERM OFF;
REM
REM $Header: 215187.1 sqdold.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqdold.sql
REM
REM DESCRIPTION
REM   Drops deprecated old SQLTXPLAIN schema objects from SQLT tool.
REM
REM PRE-REQUISITES
REM   1. To drop deprecated SQLTXPLAIN objects you must connect
REM      INTERNAL(SYS) as SYSDBA, or as SQLTXPLAIN.
REM
REM PARAMETERS
REM   1. None
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory
REM   2. Start SQL*Plus connecting INTERNAL(SYS) as SYSDBA
REM      or as SQLTXPLAIN
REM   3. Execute script sqdold.sql
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqdold.sql
REM
REM NOTES
REM   1. This script is executed automatically by sqdrop.sql
REM      and sqcreate.sql
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common

SET ECHO OFF TERM ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF USER NOT IN ('SYS', 'SQLTXPLAIN') THEN
    RAISE_APPLICATION_ERROR(-20100, 'Drop of deprecated old SQLTXPLAIN objects failed. Connect as SYS or SQLTXPLAIN, not as '||USER);
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;
SET ECHO ON TERM OFF;

/* - older versions of XPLORE - */
DROP PUBLIC SYNONYM v$parameter_exadata;
DROP PUBLIC SYNONYM v$parameter_cbo;
DROP PUBLIC SYNONYM v$parameter_lov;

/* - older versions of XPLORE - */
DROP VIEW sys.v$parameter_exadata;
DROP VIEW sys.v$parameter_cbo;
DROP VIEW sys.v$parameter_lov;

/* - packages - */
DROP PACKAGE BODY sqltxplain.sqlt$p;
DROP PACKAGE      sqltxplain.sqlt$p;

/* - procedures - */
DROP PROCEDURE sqltxplain.sqlt$_execute_tuning_task;

/* - sys views created and used by sqlt - */
DROP VIEW sys.dba_col_stats_versions;
DROP VIEW sys.dba_col_usage$;
DROP VIEW sys.dba_histgrm_stats_versions;
DROP VIEW sys.dba_ind_stats_versions;
DROP VIEW sys.dba_tab_stats_versions;
DROP VIEW sys.gv$parameter_cbo;
DROP VIEW sys.my_v$session;
DROP VIEW sys.sqlt$_gv$parameter_cbo;

/* - views - */
DROP VIEW sqltxplain.log;
DROP VIEW sqltxplain.sqlg$_join_order_v1;
DROP VIEW sqltxplain.sqlg$_join_order_v2;
DROP VIEW sqltxplain.sqlt$_dba_ind_statistics;
DROP VIEW sqltxplain.sqlt$_dba_outline_hints;
DROP VIEW sqltxplain.sqlt$_dba_outline_nodes;
DROP VIEW sqltxplain.sqlt$_dba_outlines;
DROP VIEW sqltxplain.sqlt$_dba_part_col_stats;
DROP VIEW sqltxplain.sqlt$_dba_segments;
DROP VIEW sqltxplain.sqlt$_dba_subpart_col_stats;
DROP VIEW sqltxplain.sqlt$_dba_tab_col_statistics;
DROP VIEW sqltxplain.sqlt$_dba_tab_cols;
DROP VIEW sqltxplain.sqlt$_dba_tab_statistics;
DROP VIEW sqltxplain.sqlt$_gv$parameter2;
DROP VIEW sqltxplain.sqlt$_gv$sql;
DROP VIEW sqltxplain.sqlt$_gv$sql_plan;
DROP VIEW sqltxplain.sqlt$_gv$sql_plan_statistics;
DROP VIEW sqltxplain.sqlt$_gv$sql_workarea;
DROP VIEW sqltxplain.sqlt$_gv$sqltext_with_newlines;
DROP VIEW sqltxplain.sqlt$_gv$system_parameter2;
DROP VIEW sqltxplain.sqlt$_sql_baseline_hints_v;
DROP VIEW sqltxplain.sqlt$_v$session;
DROP VIEW sqltxplain.sqlt$_v$sql;
DROP VIEW sqltxplain.sqlt$_v$sql_plan;
DROP VIEW sqltxplain.sqlt$_v$sql_plan_statistics;
DROP VIEW sqltxplain.sqlt$_v$sql_workarea;
DROP VIEW sqltxplain.sqlt$_v$sqltext_with_newlines;

/* - tables - */
DROP TABLE sqltxplain.sqlg$_10053_parse;
DROP TABLE sqltxplain.sqlg$_adv_rationale;
DROP TABLE sqltxplain.sqlg$_dba_hist_snapshot;
DROP TABLE sqltxplain.sqlg$_dba_hist_sql_plan;
DROP TABLE sqltxplain.sqlg$_dba_hist_sqlstat;
DROP TABLE sqltxplain.sqlg$_dba_hist_sqltext;
DROP TABLE sqltxplain.sqlg$_dba_part_histograms;
DROP TABLE sqltxplain.sqlg$_dba_subpart_histograms;
DROP TABLE sqltxplain.sqlg$_dba_tab_histograms;
DROP TABLE sqltxplain.sqlg$_dbms_xplan;
DROP TABLE sqltxplain.sqlg$_error;
DROP TABLE sqltxplain.sqlg$_gv$sql_bind_capture;
DROP TABLE sqltxplain.sqlg$_gv$sql_shared_cursor;
DROP TABLE sqltxplain.sqlg$_histogram_cols;
DROP TABLE sqltxplain.sqlg$_join_order;
DROP TABLE sqltxplain.sqlg$_object_dependency;
DROP TABLE sqltxplain.sqlg$_objects;
DROP TABLE sqltxplain.sqlg$_optstat_aux_history;
DROP TABLE sqltxplain.sqlg$_optstat_histgrm_history;
DROP TABLE sqltxplain.sqlg$_optstat_histhead_history;
DROP TABLE sqltxplain.sqlg$_optstat_ind_history;
DROP TABLE sqltxplain.sqlg$_optstat_opr;
DROP TABLE sqltxplain.sqlg$_optstat_tab_history;
DROP TABLE sqltxplain.sqlg$_peeked_binds;
DROP TABLE sqltxplain.sqlg$_pivot;
DROP TABLE sqltxplain.sqlg$_sql;
DROP TABLE sqltxplain.sqlg$_sql_monitor;
DROP TABLE sqltxplain.sqlg$_sql_plan;
DROP TABLE sqltxplain.sqlg$_sql_plan_monitor;
DROP TABLE sqltxplain.sqlg$_sql_plan_statistics;
DROP TABLE sqltxplain.sqlg$_sql_workarea;
DROP TABLE sqltxplain.sqlg$_statement_tune;
DROP TABLE sqltxplain.sqlg$_tab_part_columns;
DROP TABLE sqltxplain.sqlg$_tab_subpart_columns;
DROP TABLE sqltxplain.sqlg$_tablespaces;
DROP TABLE sqltxplain.sqlg$_warning;
DROP TABLE sqltxplain.sqlg$_xplore_test;
DROP TABLE sqltxplain.sqli$_parameter_apps;
DROP TABLE sqltxplain.sqli$_segments;
DROP TABLE sqltxplain.sqli$_tool_parameter;
DROP TABLE sqltxplain.sqlt$_10053_parse;
DROP TABLE sqltxplain.sqlt$_adv_rationale;
DROP TABLE sqltxplain.sqlt$_constraints;
DROP TABLE sqltxplain.sqlt$_error;
DROP TABLE sqltxplain.sqlt$_gv$sql_bind_capture;
DROP TABLE sqltxplain.sqlt$_hist_files;
DROP TABLE sqltxplain.sqlt$_histogram_cols;
DROP TABLE sqltxplain.sqlt$_ind_partitions;
DROP TABLE sqltxplain.sqlt$_ind_statistics;
DROP TABLE sqltxplain.sqlt$_ind_subpartitions;
DROP TABLE sqltxplain.sqlt$_object_dependency;
DROP TABLE sqltxplain.sqlt$_objects;
DROP TABLE sqltxplain.sqlt$_optstat_ind_history;
DROP TABLE sqltxplain.sqlt$_optstat_tab_history;
DROP TABLE sqltxplain.sqlt$_outline_hints;
DROP TABLE sqltxplain.sqlt$_outlines;
DROP TABLE sqltxplain.sqlt$_parameter;
DROP TABLE sqltxplain.sqlt$_parameter_apps;
DROP TABLE sqltxplain.sqlt$_segment_statistics;
DROP TABLE sqltxplain.sqlt$_segments;
DROP TABLE sqltxplain.sqlt$_session_event;
DROP TABLE sqltxplain.sqlt$_sesstat;
DROP TABLE sqltxplain.sqlt$_sql;
DROP TABLE sqltxplain.sqlt$_sql_monitor;
DROP TABLE sqltxplain.sqlt$_sql_plan;
DROP TABLE sqltxplain.sqlt$_sql_plan_monitor;
DROP TABLE sqltxplain.sqlt$_sql_plan_statistics;
DROP TABLE sqltxplain.sqlt$_sql_profile_hints;
DROP TABLE sqltxplain.sqlt$_sql_profiles;
DROP TABLE sqltxplain.sqlt$_sql_workarea;
DROP TABLE sqltxplain.sqlt$_statement_tune;
DROP TABLE sqltxplain.sqlt$_stattab_temp;
DROP TABLE sqltxplain.sqlt$_tab_col_statistics;
DROP TABLE sqltxplain.sqlt$_tab_part_columns;
DROP TABLE sqltxplain.sqlt$_tab_partitions;
DROP TABLE sqltxplain.sqlt$_tab_statistics;
DROP TABLE sqltxplain.sqlt$_tab_subpart_columns;
DROP TABLE sqltxplain.sqlt$_tab_subpartitions;
DROP TABLE sqltxplain.sqlt$_tables;
DROP TABLE sqltxplain.sqlt$_tablespaces;
DROP TABLE sqltxplain.sqlt$_tool_parameter;
DROP TABLE sqltxplain.sqlt$_warning;

/* - sequences - */
DROP SEQUENCE sqltxplain.sqlg$_error_id_s;
DROP SEQUENCE sqltxplain.sqlt$_error_id_s;
DROP SEQUENCE sqltxplain.sqlt$_line_id_s;
DROP SEQUENCE sqltxplain.sqlt$_pk_id_s;
DROP SEQUENCE sqltxplain.sqlt$_statement_id_s;

/* - types */
DROP TYPE sqltxplain.bind_nt;
DROP TYPE sqltxplain.bind_t;
DROP TYPE sqltxplain.varchar2_table;

SET ECHO OFF TERM ON;
PRO
PRO SQDOLD completed. Ignore errors from this script
