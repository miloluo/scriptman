SET ECHO ON TERM OFF;
SPO 01_sqcreate.log;
REM
REM $Header: 215187.1 sqcreate.sql 11.4.4.1 2012/01/02 carlos.sierra $
REM
REM Copyright (c) 2000-2012, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   carlos.sierra@oracle.com
REM
REM SCRIPT
REM   sqlt/install/sqcreate.sql
REM
REM DESCRIPTION
REM   Installs the SQLT tool under its own schema SQLTXPLAIN.
REM
REM PRE-REQUISITES
REM   1. To install SQLT you must connect INTERNAL(SYS) as SYSDBA.
REM
REM PARAMETERS (specified inline)
REM   1. Connect Identifier. (optional).
REM      Some restricted-access systems may need to specify
REM      a connect identifier like "@PROD".
REM      This optional parameter allows to enter it. Else,
REM      enter nothing and just hit the "Enter" key.
REM   2. SQLTXPLAIN password (required).
REM      It may be case sensitive in some systems.
REM   3. Default tablespace for user SQLTXPLAIN (required).
REM      You will be presented with a list, then you will
REM      have to enter one tablespace name from that list.
REM   4. Temporary tablespace for user SQLTXPLAIN (required).
REM   5. Main application user of SQLT (optional).
REM      This is the user name that will later execute SQLT.
REM      You can add aditional SQLT users by granting them
REM      role SQLT_USER_ROLE after the tool is installed.
REM   6. Do you have a license for the Oracle Diagnostic or
REM      the Oracle Tuning Pack? (required).
REM      This enables or disables access to licensed
REM      features of the these packages. Defaults to Tuning.
REM
REM EXECUTION
REM   1. Navigate to sqlt/install directory.
REM   2. Start SQL*Plus and connect INTERNAL(SYS) as SYSDBA.
REM   3. Execute script sqcreate.sql and enter parameter
REM      values when asked.
REM
REM EXAMPLE
REM   # cd sqlt/install
REM   # sqlplus / as sysdba
REM   SQL> START sqcreate.sql
REM
REM NOTES
REM   1. For possible errors see all *.log generated files.
REM   2. Trace Analyzer TRCA 224270.1 is also installed.
REM
-- begin common
DEF _SQLPLUS_RELEASE
SELECT USER FROM DUAL;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') current_time FROM DUAL;
SELECT * FROM v$version;
SELECT * FROM v$instance;
SELECT name, value FROM v$parameter2 WHERE name LIKE '%dump_dest';
SELECT directory_name||' '||directory_path directories FROM dba_directories WHERE directory_name LIKE 'SQLT$%' OR directory_name LIKE 'TRCA$%' ORDER BY 1;
-- end common
SET ECHO OFF TERM OFF;
DEF tool_owner = SQLTXPLAIN
DEF role_name = SQLT_USER_ROLE
DEF temporary_or_permanent = T
-- initial validation
@@sqcval0.sql
-- enter installation parameters
@@sqcparameters.sql
-- validates all parameters
@@sqcval1.sql
@@sqcval2.sql
@@sqcval3.sql
@@sqcval4.sql
@@sqcval5.sql
@@sqcval6.sql
-- drops TRCA objects owned by SQLTXPLAIN
@@tadobj.sql
-- drops old objects not used by this version of SQLT
@@sqdold.sql
-- creates or recreates user SQLTXPLAIN
@@sqcusr.sql
-- create SQLT and TRCA directories
@@tasqdirset.sql
-- connects as SQLTXPLAIN
WHENEVER SQLERROR EXIT SQL.SQLCODE;
CONNECT sqltxplain/"&&sqltxplain_password."&&connect_identifier.
WHENEVER SQLERROR CONTINUE;
UNDEFINE sqltxplain_password re_enter_password
--ALTER SESSION DISABLE GUARD; (un-comment only for DG)
-- verifies that SQLTXPLAIN can actually read and write files (1st pass)
@@tautltest.sql
@@squtltest.sql
-- creates TRCA schema objects owned by SQLTXPLAIN
@@tacobj.sql
-- creates TRCA set of packages owned by SQLTXPLAIN
@@tacpkg.sql
-- creates SQLT schema objects
@@sqcobj.sql
-- creates some old SQLT schema objects (used by COMPARE)
@@sqcold.sql
-- seeds configuration parameters and data
@@sqseed.sql
-- creates SQLT set of packages and migrates old repository
@@sqcpkg.sql

PRO
PRO Taking a snapshot of some Data Dictionary objects, please wait...
PRO
EXEC trca$t.refresh_trca$_dict_from_this;
PRO
PRO Snapshot of some Data Dictionary objects completed.
PRO

-- verifies that SQLTXPLAIN can actually read and write files (2nd pass)
@@tautltest.sql
@@squtltest.sql
UNDEFINE tool_owner role_name temporary_or_permanent pack_license connect_identifier
PRO
PRO SQCREATE completed. Installation completed successfully.
